import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";

export default function AllProducts() {
  return (
    <>
      <Navbar />
      {/* PRODUCTS */}

      <section className="section products shadow-lg p-3 mb-5 bg-body-tertiary rounded">
        <div className="products-layout container">
          <div className="col-1-of-4">
            <div>
              <div className="block-title">
                <h3>Category</h3>
              </div>
              <ul className="block-content">
                <li>
                  <label htmlFor="">
                    <span>All vegetbales</span>
                    <small>(10)</small>
                  </label>
                </li>
                <li>
                  <label htmlFor="">
                    <span>Green leafy vegetables</span>
                    <small>(7)</small>
                  </label>
                </li>
                <li>
                  <label htmlFor="">
                    <span> Root vegetabeles</span>
                    <small>(3)</small>
                  </label>
                </li>
                <li>
                  <label htmlFor="">
                    <span> Sprouts</span>
                    <small>(3)</small>
                  </label>
                </li>
                <li>
                  <label htmlFor="">
                    <span> Fruits</span>
                    <small>(10)</small>
                  </label>
                </li>
                <li>
                  <label htmlFor="">
                    <span>Fruit Juices</span>
                    <small>(15)</small>
                  </label>
                </li>
              </ul>
            </div>
            <div>
              <div className="block-title">
                <h3>Organic Juice Brands</h3>
              </div>
              <ul className="block-content">
                <li>
                  <a href="/html_pages/Product_details_Juice_Brands/almaverde.html"></a>
                  <label htmlFor="">
                    <span>Almaverde Bio</span>
                    <small>(10)</small>
                  </label>
                </li>
                <li>
                  <a href="/html_pages/Product_details_Juice_Brands/frootee.html"></a>
                  <label htmlFor="">
                    <span>Frootee </span>
                    <small>(7)</small>
                  </label>
                </li>
                <li>
                  <a href="/html_pages/Product_details_Juice_Brands/goodEart.html"></a>
                  <label htmlFor="">
                    <span> Good Earth</span>
                    <small>(3)</small>
                  </label>
                </li>
                <li>
                  <a href="/html_pages/Product_details_Juice_Brands/greenJuice.html"></a>
                  <label htmlFor="">
                    <span>Green juice</span>
                    <small>(3)</small>
                  </label>
                </li>
                <li>
                  <a href="/html_pages/Product_details_Juice_Brands/juiceLife.html"></a>
                  <label htmlFor="">
                    <span>Juice Life</span>
                    <small>(3)</small>
                  </label>
                </li>
                <li>
                  <a href="/html_pages/Product_details_Juice_Brands/edenOrganic.html"></a>
                  <label htmlFor="">
                    <span>Eden Organic</span>
                    <small>(3)</small>
                  </label>
                </li>
                <li>
                  <a href="/html_pages/Product_details_Juice_Brands/hippieJuice.html"></a>
                  <label htmlFor="">
                    <span>Hippie Juice</span>
                    <small>(3)</small>
                  </label>
                </li>
                <li>
                  <a href="/html_pages/Product_details_Juice_Brands/juice.html"></a>
                  <label htmlFor="">
                    <span>Juice</span>
                    <small>(3)</small>
                  </label>
                </li>
                <li>
                  <a href="/html_pages/Product_details_Juice_Brands/fruitAuthority.html"></a>
                  <label htmlFor="">
                    <span>Fruit Authority</span>
                    <small>(3)</small>
                  </label>
                </li>
                <li>
                  <a href="/html_pages/Product_details_Juice_Brands/limonFreshness.html"></a>
                  <label htmlFor="">
                    <span>Limon Freshness</span>
                    <small>(3)</small>
                  </label>
                </li>
              </ul>
            </div>
          </div>
          {/sort category div top/}
          <div className="col-3-of-4">
            <form action="">
              <div className="item">
                <label htmlFor="sort-by">Sort By</label>
                <select name="sort-by" id="sort-by">
                  <option value="title" selected="selected">
                    Min Price
                  </option>
                  <option value="number">Max Price</option>
                  <option value="search_api_relevance">Relevance</option>
                  <option value="created">Featured</option>
                </select>
              </div>
              <div className="item">
                <label htmlFor="order-by">Order</label>
                <select name="order-by" id="sort-by">
                  <option value="ASC" selected="selected">
                    ASC
                  </option>
                  <option value="DESC">DESC</option>
                </select>
              </div>
              <a href="">Apply</a>
            </form>
            {/*All products (some changes to add)*/}
            <div className="product-layout">
              <div className="product">
                <div className="img-container ">
                  <img src="/images/vgg (1).jpg" alt="" />
                  <div className="addCart">
                    <i className="fas fa-shopping-cart" />
                  </div>
                  <ul className="side-icons">
                    <span>
                      <i className="far fa-heart" />
                    </span>
                    <span>
                      <i className="fas fa-sliders-h" />
                    </span>
                  </ul>
                </div>
                <div className="bottom">
                  <a href="productDetails.html">Cucumber</a>
                  <div className="price">
                    <span>₹70</span>
                  </div>
                </div>
              </div>
              <div className="product">
                <div className="img-container">
                  <img src="/images/vgg (2).jpg" alt="" />
                  <div className="addCart">
                    <i className="fas fa-shopping-cart" />
                  </div>
                  <ul className="side-icons">
                    <span>
                      <i className="far fa-heart" />
                    </span>
                    <span>
                      <i className="fas fa-sliders-h" />
                    </span>
                  </ul>
                </div>
                <div className="bottom">
                  <a href="">Garlic</a>
                  <div className="price">
                    <span>₹80</span>
                  </div>
                </div>
              </div>
              <div className="product">
                <div className="img-container">
                  <img src="/images/vgg (3).jpg" alt="" />
                  <div className="addCart">
                    <i className="fas fa-shopping-cart" />
                  </div>
                  <ul className="side-icons">
                    <span>
                      <i className="far fa-heart" />
                    </span>
                    <span>
                      <i className="fas fa-sliders-h" />
                    </span>
                  </ul>
                </div>
                <div className="bottom">
                  <a href="">Mix Bell pepers</a>
                  <div className="price">
                    <span>₹120</span>
                  </div>
                </div>
              </div>
              <div className="product">
                <div className="img-container">
                  <img src="/images/vgg (4).jpg" alt="" />
                  <div className="addCart">
                    <i className="fas fa-shopping-cart" />
                  </div>
                  <ul className="side-icons">
                    <span>
                      <i className="far fa-heart" />
                    </span>
                    <span>
                      <i className="fas fa-sliders-h" />
                    </span>
                  </ul>
                </div>
                <div className="bottom">
                  <a href="">Cauliflower</a>
                  <div className="price">
                    <span>₹80</span>
                  </div>
                </div>
              </div>
              <div className="product">
                <div className="img-container">
                  <img src="/images/vgg (5).jpg" alt="" />
                  <div className="addCart">
                    <i className="fas fa-shopping-cart" />
                  </div>
                  <ul className="side-icons">
                    <span>
                      <i className="far fa-heart" />
                    </span>
                    <span>
                      <i className="fas fa-sliders-h" />
                    </span>
                  </ul>
                </div>
                <div className="bottom">
                  <a href="">Zuccini</a>
                  <div className="price">
                    <span>₹80</span>
                  </div>
                </div>
              </div>
              <div className="product">
                <div className="img-container">
                  <img src="/images/vgg (6).jpg" alt="" />
                  <div className="addCart">
                    <i className="fas fa-shopping-cart" />
                  </div>
                  <ul className="side-icons">
                    <span>
                      <i className="far fa-heart" />
                    </span>
                    <span>
                      <i className="fas fa-sliders-h" />
                    </span>
                  </ul>
                </div>
                <div className="bottom">
                  <a href="">Palak</a>
                  <div className="price">
                    <span>₹60</span>
                  </div>
                </div>
              </div>
              <div className="product">
                <div className="img-container">
                  <img src="/images/vgg (7).jpg" alt="" />
                  <div className="addCart">
                    <i className="fas fa-shopping-cart" />
                  </div>
                  <ul className="side-icons">
                    <span>
                      <i className="far fa-heart" />
                    </span>
                    <span>
                      <i className="fas fa-sliders-h" />
                    </span>
                  </ul>
                </div>
                <div className="bottom">
                  <a href="">Red capsicum</a>
                  <div className="price">
                    <span>₹80</span>
                  </div>
                </div>
              </div>
              <div className="product">
                <div className="img-container">
                  <img src="/images/vgg (8).jpg" alt="" />
                  <div className="addCart">
                    <i className="fas fa-shopping-cart" />
                  </div>
                  <ul className="side-icons">
                    <span>
                      <i className="far fa-heart" />
                    </span>
                    <span>
                      <i className="fas fa-sliders-h" />
                    </span>
                  </ul>
                </div>
                <div className="bottom">
                  <a href="">Onions</a>
                  <div className="price">
                    <span>₹100</span>
                  </div>
                </div>
              </div>
              <div className="product">
                <div className="img-container">
                  <img src="/images/vgg (10).jpg" alt="" />
                  <div className="addCart">
                    <i className="fas fa-shopping-cart" />
                  </div>
                  <ul className="side-icons">
                    <span>
                      <i className="far fa-heart" />
                    </span>
                    <span>
                      <i className="fas fa-sliders-h" />
                    </span>
                  </ul>
                </div>
                <div className="bottom">
                  <a href="">Kashmiri Chilli</a>
                  <div className="price">
                    <span>₹80</span>
                  </div>
                </div>
              </div>
              <div className="product">
                <div className="img-container">
                  <img src="/images/vgg (11).jpg" alt="" />
                  <div className="addCart">
                    <i className="fas fa-shopping-cart" />
                  </div>
                  <ul className="side-icons">
                    <span>
                      <i className="far fa-heart" />
                    </span>
                    <span>
                      <i className="fas fa-sliders-h" />
                    </span>
                  </ul>
                </div>
                <div className="bottom">
                  <a href="">Bok Choy</a>
                  <div className="price">
                    <span>₹80</span>
                  </div>
                </div>
              </div>
              <div className="product">
                <div className="img-container">
                  <img src="/images/fr1.jpg" alt="" />
                  <div className="addCart">
                    <i className="fas fa-shopping-cart" />
                  </div>
                  <ul className="side-icons">
                    <span>
                      <i className="far fa-heart" />
                    </span>
                    <span>
                      <i className="fas fa-sliders-h" />
                    </span>
                  </ul>
                </div>
                <div className="bottom">
                  <a href="">Dragon Fruit </a>
                  <div className="price">
                    <span>₹120</span>
                  </div>
                </div>
              </div>
              <div className="product">
                <div className="img-container">
                  <img src="/images/fr3.jpg" alt="" />
                  <div className="addCart">
                    <i className="fas fa-shopping-cart" />
                  </div>
                  <ul className="side-icons">
                    <span>
                      <i className="far fa-heart" />
                    </span>
                    <span>
                      <i className="fas fa-sliders-h" />
                    </span>
                  </ul>
                </div>
                <div className="bottom">
                  <a href="">Grapes </a>
                  <div className="price">
                    <span>₹120</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* PAGINATION */}
        <ul className="pagination">
          <span>1</span>
          <span>2</span>
          <span>3</span>
          <span>4</span>
          <span className="icon">››</span>
          <span className="last">Last »</span>
        </ul>
      </section>

      <Footer />
    </>
  );
}
