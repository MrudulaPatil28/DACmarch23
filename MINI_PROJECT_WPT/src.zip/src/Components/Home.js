import React from "react";
import Featured from "./Featured";
import Navbar from "./Navbar";
import Topcarousel from "./Topcarousel";
import Collection from "./Collection";
import Exotic from "./Exotic";
import FreshJuices from "./FreshJuices";
import Btmcarousel from "./Btmcarousel";
import Footer from "./Footer";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div>
      <Navbar />
      <Topcarousel />
      <Featured />
      <Collection />
      <Exotic />
      <FreshJuices />
      <Btmcarousel />
      <Footer />
    </div>
  );
}
