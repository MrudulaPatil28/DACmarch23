// import { useRef, useState } from "react";
// import Navbar from "./Navbar";
// import Footer from "./Footer";
// import { Link } from "react-router-dom";

// function SignUp() {
//   let formRef = useRef();
//   let [user, setUser] = useState({
//     username: "",
//     password: "",
//     email: "",
//     mobile: "",
//   });
//   let handlerUsernameAction = (e) => {
//     let newUser = { ...user, username: e.target.value };
//     setUser(newUser);
//   };

//   let handlerPasswordAction = (e) => {
//     let newUser = { ...user, password: e.target.value };
//     setUser(newUser);
//   };

//   let handlerEmailAction = (e) => {
//     let newUser = { ...user, email: e.target.value };
//     setUser(newUser);
//   };

//   let handlerMobileAction = (e) => {
//     let newUser = { ...user, mobile: e.target.value };
//     setUser(newUser);
//   };

//   // let resetAction = () => {
//   //   let newUser = {
//   //     name: "",
//   //     email: "",
//   //     username: "",
//   //     password: "",
//   //     mobile: "",
//   //   };
//   //   setUser(newUser);
//   // };

//   let registerAction = async (e) => {
//     e.preventDefault();
//     // if (isNaN(user.mobile)) {
//     //   document.getElementById("mobileno").innerHTML =
//     //     " ** user must write digits only not characters";
//     //   return false;
//     // } else {
//     //   document.getElementById("mobileno").innerHTML = "";
//     // }

//     formRef.current.classList.add("was-validated");
//     let formStatus = formRef.current.checkValidity();
//     if (!formStatus) {
//       return;
//     }

//     let url = `http://localhost:5000/adduser?username=${user.username}&password=${user.password}&email=${user.email}&mobile=${user.mobile}`;
//     await fetch(url);

//     window.alert(`Username : ${user.username}`);
//     let newUser = {
//       username: "",
//       password: "",
//       email: "",
//       mobile: "",
//     };
//     setUser(newUser);

//     formRef.current.classList.remove("was-validated");
//   };

//   // function SignUp() {
//   //   let formRef = useRef();
//   //   let [isSuccess, setIsSuccess] = useState(false);
//   //   let [isError, setIsError] = useState(false);

//   //   let [user, setUser] = useState({
//   //     username: "",
//   //     password: "",
//   //     email: "",
//   //     mobile: "",
//   //   });

//   //   let handlerUsernameAction = (e) => {
//   //     let newuser = { ...user, username: e.target.value };
//   //     setUser(newuser);
//   //   };

//   //   let handlerPasswordAction = (e) => {
//   //     let newuser = { ...user, password: e.target.value };
//   //     setUser(newuser);
//   //   };

//   //   let handlerEmailAction = (e) => {
//   //     let newuser = { ...user, email: e.target.value };
//   //     setUser(newuser);
//   //   };

//   //   let handlerMobileAction = (e) => {
//   //     let newuser = { ...user, mobile: e.target.value };
//   //     setUser(newuser);
//   //   };

//   //   let registerAction = async (e) => {
//   //     e.preventDefault();
//   //     // try {
//   //     formRef.current.classList.add("was-validated");
//   //     let formStatus = formRef.current.checkValidity();
//   //     if (!formStatus) {
//   //       return;
//   //     }

//   //     // BACKEND
//   //     let url = `http://localhost:5000/adduser?username=${user.username}&password=${user.password}&email=${user.email}&mobile=${user.mobile}`;

//   //     let res = await fetch(url);

//   //     // if (res.status != 200) {
//   //     //   let serverMsg = await res.text();
//   //     //   throw new Error(serverMsg);
//   //     // }

//   //     let newuser = {
//   //       username: "",
//   //       password: "",
//   //       email: "",
//   //       mobile: "",
//   //     };
//   //     setUser(newuser);

//   //     formRef.current.classList.remove("was-validated");

//   //     alert("success");
//   //     setIsSuccess(true);
//   //     // } catch (err) {
//   //     //   alert(err.message);
//   //     //   setIsError(true);
//   //     // } finally {
//   //     //   setTimeout(() => {
//   //     //     setIsSuccess(false);
//   //     //     setIsError(false);
//   //     //   }, 5000);
//   //     // }
//   //   };

//   return (
//     <>
//       <Navbar />
//       {/* SignUp */}
//       <div className="container bgimg">
//         <div className="login-form">
//           <form action="login.html">
//             <h1>Sign Up</h1>
//             <p className="fs-5">
//               Please fill in this form to create an account or &nbsp;
//               <Link to={"/login"}>Login</Link>
//             </p>
//             <label id="pass" htmlFor="psw" className="fs-5">
//               Name
//             </label>
//             <input
//               value={user.username}
//               type="text"
//               placeholder="Enter User Name"
//               id="regName"
//               maxLength={32}
//               //pattern="^[A-Za-z\s]{3,20}$ "
//               title="Do not Enter numeric value"
//               onChange={handlerUsernameAction}
//               required
//             />
//             <label id="pass" htmlFor="psw" className="fs-5">
//               Password
//             </label>
//             <input
//               value={user.password}
//               type="password"
//               placeholder="Enter Password"
//               //pattern="(?=.*\d)(?=.[a-z])(?=.*[A-Z]).{8,}"
//               title="Must contain at least one number and one Upper case"
//               id="psw"
//               onChange={handlerPasswordAction}
//               required
//             />

//             <label id="email-label" className="fs-5">
//               Email
//             </label>
//             <input
//               value={user.email}
//               id="uname"
//               type="email"
//               //pattern="[a-z]+@[a-z0-9-]+\.[a-z]{2,}$"
//               placeholder="Enter Email"
//               name="email"
//               spellCheck="false"
//               onChange={handlerEmailAction}
//               required
//             />

//             <label className="fs-5"> Mobile Number </label>
//             <input
//               value={user.mobile}
//               id="phone"
//               type="tel"
//               maxLength={10}
//               minLength={10}
//               //pattern="[789][0-9]{9}"
//               placeholder="Enter your number"
//               onChange={handlerMobileAction}
//               required
//             />

//             <label>
//               <input
//                 type="checkbox"
//                 uchecked=""
//                 name="remember"
//                 style={{ marginBottom: 15 }}
//               />
//               Remember me
//             </label>
//             <p className="fs-5">
//               By creating an account you agree to our
//               <a href="#">Terms &amp; Privacy</a>.
//             </p>
//             <div className="buttons">
//               <button type="reset" className="cancelbtn">
//                 Cancel
//               </button>
//               <button
//                 type="submit"
//                 className="signupbtn"
//                 onClick={registerAction}
//               >
//                 Sign Up
//               </button>
//             </div>
//           </form>
//           {/* {isSuccess && <div className="alert alert-success">Success</div>}
//           {isError && <div className="alert alert-danger">Error</div>} */}
//         </div>
//       </div>
//       {/* SignUp End*/}
//       <Footer />
//     </>
//   );
// }
// export default SignUp;

import React, { useRef, useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";

function RegisterForm() {
  let formRef = useRef();
  let [user, setUser] = useState({
    email: "",
    username: "",
    password: "",
    mobile: "",
  });

  let handlerEmailAction = (e) => {
    let newUser = { ...user, email: e.target.value };
    setUser(newUser);
  };
  let handlerUsernameAction = (e) => {
    let newUser = { ...user, username: e.target.value };
    setUser(newUser);
  };

  let handlerPasswordAction = (e) => {
    let newUser = { ...user, password: e.target.value };
    setUser(newUser);
  };

  let handlerMobileAction = (e) => {
    let newUser = { ...user, mobile: e.target.value };
    setUser(newUser);
  };

  let resetAction = () => {
    let newUser = {
      email: "",
      username: "",
      password: "",
      mobile: "",
    };
    setUser(newUser);
  };

  let registerAction = async (e) => {
    e.preventDefault();
    if (isNaN(user.mobile)) {
      document.getElementById("mobileno").innerHTML =
        " ** user must write digits only not characters";
      return false;
    } else {
      document.getElementById("mobileno").innerHTML = "";
    }

    formRef.current.classList.add("was-validated");
    let formStatus = formRef.current.checkValidity();
    if (!formStatus) {
      return;
    }

    let url = `http://localhost:5000/adduser?username=${user.username}&password=${user.password}&email=${user.email}&mobile=${user.mobile}`;
    await fetch(url);

    window.alert(`Username : ${user.username} registered successfully!`);
    let newUser = {
      email: "",
      username: "",
      password: "",
      mobile: "",
    };
    setUser(newUser);

    formRef.current.classList.remove("was-validated");
  };

  return (
    <>
      <Navbar />
      <div className="container bgimg">
        <div className="login-form">
          <form ref={formRef} className="needs-validation" action="login.html">
            <h1>Sign Up</h1>
            <p className="fs-5">
              Please fill in this form to create an account or &nbsp;
              <Link to={"/login"}>Login</Link>
            </p>
            <div className="form-group mb-2">
              <label className="fs-5"> Email </label>
              <input
                type="email"
                name="email"
                className="form-control  border-dark"
                id="emails"
                value={user.email}
                autoComplete="off"
                pattern="[a-z]+@[a-z0-9-]+.[a-z]{5,}$"
                title="Enter valid email id"
                placeholder="Enter Email"
                onChange={handlerEmailAction}
                required
              />
              <span
                id="emailids"
                className="text-danger font-weight-regular"
              ></span>
            </div>
            <div className="form-group mb-2">
              <label htmlFor="user" className="fs-5">
                Username
              </label>
              <input
                type="text"
                name="user"
                className="form-control  border-dark"
                placeholder="Enter User Name"
                id="user"
                value={user.username}
                autoComplete="off"
                onChange={handlerUsernameAction}
                pattern="^[A-Za-z\s]{3,20}"
                title="Do not Enter numeric value"
                minLength="5"
                maxLength="20"
                required
              />
              <span
                id="username"
                className="text-danger font-weight-regular"
              ></span>
            </div>
            <div className="form-group mb-2">
              <label className="fs-5"> Password </label>
              <input
                type="password"
                name="pass"
                className="form-control  border-dark"
                id="pass"
                placeholder="Enter Password"
                pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$&]).{8,30}"
                title="Min 8 charaters, Must contain: 1st letter Upper case, 1 lower case, 1 number, 1 symbol(!@#$&)"
                value={user.password}
                autoComplete="off"
                onChange={handlerPasswordAction}
                minLength="8"
                maxLength="30"
                required
              />
              <span
                id="passwords"
                className="text-danger font-weight-regular"
              ></span>
            </div>
            {/* <div className="form-group mb-2">
              <label className="font-weight-regular"> Confirm Password </label>
              <input
                type="password"
                name="conpass"
                className="form-control  border-dark"
                id="conpass"
                autoComplete="off"
              />
              <span
                id="confrmpass"
                className="text-danger font-weight-regular"
              ></span>
            </div> */}
            <div className="form-group ">
              <label className="fs-5"> Mobile Number </label>
              <input
                type="text"
                name="mobile"
                className="form-control border-dark"
                id="mobileNumber"
                autoComplete="off"
                value={user.mobile}
                
                title="Enter 10 digit valid number"
                placeholder="Enter your number"

                pattern="[789][0-9]{9}"
                minLength="10"
                maxLength="10"
                onChange={handlerMobileAction}
                required
              />
              <span
                id="mobileno"
                className="text-danger font-weight-regular"
              ></span>
            </div>
            <p className="fs-5">
              By creating an account you agree to our
              <a href="#">Terms &amp; Privacy</a>.
            </p>
            <div className="buttons">
              <button type="reset" className="cancelbtn" onClick={resetAction}>
                Cancel
              </button>
              <button
                type="submit"
                className="signupbtn"
                onClick={registerAction}
              >
                Sign Up
              </button>
            </div>
            {/* <input
              type="button"
              name="submit"
              defaultValue="Submit"
              className="btn btn-lg btn-primary"
              onClick={registerAction}
            />
            <input
              type="reset"
              name="reset"
              defaultValue="Reset"
              className="btn btn-lg btn-secondary"
              onClick={resetAction}
            />
            <br /> */}
            <p className="fs-5">
              Already have an account? &nbsp;
              <Link to="/Login">Login</Link>
            </p>
          </form>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default RegisterForm;
