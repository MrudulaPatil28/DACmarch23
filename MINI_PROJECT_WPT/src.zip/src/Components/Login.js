import { useRef, useState } from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import { Link } from "react-router-dom";
import "./Login.css";
import { useNavigate } from "react-router-dom";

function Login() {
  let formReflogin = useRef();
  let navigate = useNavigate();

  // let [isSuccess, setIsSuccess] = useState(false);
  // let [isError, setIsError] = useState(false);

  let [user, setUser] = useState({
    email: "",
    password: "",
  });

  let handlerEmailAction = (e) => {
    let newuser = { ...user, email: e.target.value };
    setUser(newuser);
  };

  let handlerPasswordAction = (e) => {
    let newuser = { ...user, password: e.target.value };
    setUser(newuser);
  };

  // let loginAction = async () => {
  //   try {
  //     formRef.current.classList.add("was-validated");
  //     let formStatus = formRef.current.checkValidity();
  //     if (!formStatus) {
  //       return;
  //     }

  //     // TODO BACKEND :: ...
  //     navigate("/home");
  //   } catch (err) {
  //     alert(err.message);
  //     setIsError(true);
  //   }
  // };

  async function loginGet() {
    try {
      formReflogin.current.classList.add("was-validated");
      let formStatus = formReflogin.current.checkValidity();
      if (!formStatus) {
        alert("Enter input in correct format");
        return;
      }

      let url = `http//:localhost:5000/loginbyget?email=${user.email}&password=${user.password}`;

      let res = await fetch(url);

      if (res.status == 500) {
        let erroMessage = await res.text();
        throw new Error(erroMessage);
      } else {
        alert("Succes!");
      }

      localStorage.setItem("loginStatus", "true");
      navigate("/home", { replace: true });
    } catch (err) {
      alert(err.message);
    }
  }
  return (
    <>
      <Navbar />
      {/* Login */}
      <div className="container bgimg">
        <div className="login-form">
          <form action={"/"} ref={formReflogin} className="needs-validation">
            <h1>Login</h1>
            <p className="fs-5">
              Already have an account? Login in or &nbsp;
              <Link to={"signup"}>Sign-Up</Link>
            </p>

            <label id="email-label" className="fs-5">
              Email
            </label>
            <input
              id="email"
              type="email"
              value={user.email}
              pattern="[a-z]+@[a-z0-9-]+\.[a-z]{2,}$"
              placeholder="Enter Email"
              name="email"
              spellCheck="false"
              onChange={handlerEmailAction}
              required
            />
            <label htmlFor="psw" className="fs-5">
              Password
            </label>
            <input
              type="password"
              id="password"
              value={user.password}
              placeholder="Enter Password"
              name="password"
              onChange={handlerPasswordAction}
              pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$&]).{8,}"
              required
            />
            <label>
              <input
                type="checkbox"
                unchecked=""
                name="remember"
                style={{ marginBottom: 15 }}
              />
              Remember me
            </label>
            <p className="fs-5">
              By creating an account you agree to our
              <a href="#">Terms &amp; Privacy</a>.
            </p>
            <div className="buttons">
              <button>Cancel</button>
              <button onClick={loginGet}>Login</button>
            </div>
          </form>

          {/* {isSuccess && <div className="alert alert-success">Success</div>}
          {isError && <div className="alert alert-danger">Error</div>} */}
        </div>
      </div>
      {/* Login End*/}
      <Footer />
    </>
  );
}
export default Login;
