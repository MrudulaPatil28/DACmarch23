import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import v1 from "./images/v1.jpg";
import v2 from "./images/v2.jpg";
import v3 from "./images/v3.jpg";
import ju4 from "./images/ju4.jpg";
import ju5 from "./images/ju5.jpg";
import ju3 from "./images/ju3.jpg";
import ju2 from "./images/ju2.jpg";
import ju9 from "./images/ju9.jpg";
import { Link } from "react-router-dom";

function Featured() {
  return (
    <>
      <Container>
        <div className="title mb-3 mt-5">
          <h3 className="d-flex justify-content-center fs-2 fw-bold">
            Featured Products
          </h3>
          <span className="d-flex justify-content-center fs-4">
            Select from the premium product brands and save plenty money
          </span>
        </div>

        <Row className="justify-content-md-center">
          <Col xs={6} md={3} className="my-3">
            <div className="product">
              <div className="img-container">
                <img src={v1} alt="" />
                <div className="addCart">
                  <i className="fas fa-shopping-cart"></i>
                </div>

                <ul className="side-icons">
                  <span>
                    <i className="far fa-heart"></i>
                  </span>
                  <span>
                    <i className="fas fa-sliders-h"></i>
                  </span>
                </ul>
              </div>
              <div className="bottom">
                <Link className="text-decoration-none" to={"/tomato"}>
                  Tomatoes
                </Link>
                <div className="price">
                  <span>₹ 70</span>
                </div>
              </div>
            </div>
          </Col>
          <Col xs={6} md={3} className="my-3">
            <div className="product">
              <div className="img-container">
                <img src={v2} alt="" />
                <div className="addCart">
                  <i className="fas fa-shopping-cart"></i>
                </div>

                <ul className="side-icons">
                  <span>
                    <i className="far fa-heart"></i>
                  </span>
                  <span>
                    <i className="fas fa-sliders-h"></i>
                  </span>
                </ul>
              </div>
              <div className="bottom">
                <Link className="text-decoration-none" to={"/bellpepper"}>
                  BellPepper
                </Link>
                <div className="price">
                  <span>₹ 220</span>
                </div>
              </div>
            </div>
          </Col>
          <Col xs={6} md={3} className="my-3">
            <div className="product">
              <div className="img-container">
                <img src={v3} alt="" />
                <div className="addCart">
                  <i className="fas fa-shopping-cart"></i>
                </div>

                <ul className="side-icons">
                  <span>
                    <i className="far fa-heart"></i>
                  </span>
                  <span>
                    <i className="fas fa-sliders-h"></i>
                  </span>
                </ul>
              </div>
              <div className="bottom">
                <Link className="text-decoration-none" to={"/mushroom"}>
                  Mushroom
                </Link>
                <div className="price">
                  <span>₹ 120</span>
                </div>
              </div>
            </div>
          </Col>
          <Col xs={6} md={3} className="my-3">
            <div className="product">
              <div className="img-container">
                <img src={ju4} alt="" />
                <div className="addCart">
                  <i className="fas fa-shopping-cart"></i>
                </div>

                <ul className="side-icons">
                  <span>
                    <i className="far fa-heart"></i>
                  </span>
                  <span>
                    <i className="fas fa-sliders-h"></i>
                  </span>
                </ul>
              </div>
              <div className="bottom">
                <a href="" className="text-decoration-none">
                  Strawberry Juice
                </a>
                <div className="price">
                  <span>₹ 280</span>
                </div>
              </div>
            </div>
          </Col>
          <Col xs={6} md={3} className="my-3">
            <div className="product">
              <div className="img-container">
                <img src={ju5} alt="" />
                <div className="addCart">
                  <i className="fas fa-shopping-cart"></i>
                </div>

                <ul className="side-icons">
                  <span>
                    <i className="far fa-heart"></i>
                  </span>
                  <span>
                    <i className="fas fa-sliders-h"></i>
                  </span>
                </ul>
              </div>
              <div className="bottom">
                <a href="" className="text-decoration-none">
                  Pineapple Juice
                </a>
                <div className="price">
                  <span>₹ 260</span>
                </div>
              </div>
            </div>
          </Col>
          <Col xs={6} md={3} className="my-3">
            <div className="product">
              <div className="img-container">
                <img src={ju3} alt="" />
                <div className="addCart">
                  <i className="fas fa-shopping-cart"></i>
                </div>

                <ul className="side-icons">
                  <span>
                    <i className="far fa-heart"></i>
                  </span>
                  <span>
                    <i className="fas fa-sliders-h"></i>
                  </span>
                </ul>
              </div>
              <div className="bottom">
                <a href="" className="text-decoration-none">
                  Watermellon Juice
                </a>
                <div className="price">
                  <span>₹ 220</span>
                </div>
              </div>
            </div>
          </Col>
          <Col xs={6} md={3} className="my-3">
            <div className="product">
              <div className="img-container">
                <img src={ju2} alt="" />
                <div className="addCart">
                  <i className="fas fa-shopping-cart"></i>
                </div>

                <ul className="side-icons">
                  <span>
                    <i className="far fa-heart"></i>
                  </span>
                  <span>
                    <i className="fas fa-sliders-h"></i>
                  </span>
                </ul>
              </div>
              <div className="bottom">
                <a href="" className="text-decoration-none">
                  Watermellon Mojito
                </a>
                <div className="price">
                  <span>₹ 120</span>
                </div>
              </div>
            </div>
          </Col>
          <Col xs={6} md={3} className="my-3">
            <div className="product">
              <div className="img-container">
                <img src={ju9} alt="" />
                <div className="addCart">
                  <i className="fas fa-shopping-cart"></i>
                </div>

                <ul className="side-icons">
                  <span>
                    <i className="far fa-heart"></i>
                  </span>
                  <span>
                    <i className="fas fa-sliders-h"></i>
                  </span>
                </ul>
              </div>
              <div className="bottom">
                <a href="" className="text-decoration-none">
                  Pomegranate Juice
                </a>
                <div className="price">
                  <span>₹ 280</span>
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default Featured;
