import Navbar from "../Navbar";
import Footer from "../Footer";
import fr7 from "../images/fr7.jpg";
import fr14 from "../images/fr14.jpg";
import fr9 from "../images/fr9.jpg";
import fr10 from "../images/fr10.jpg";
import fr11 from "../images/fr11.jpg";
import fr13 from "../images/fr13.jpg";
import { Link } from "react-router-dom";

function Myrtleberry() {
  return (
    <>
      <Navbar />
      {/* Product Details */}
      <section className="section product-detail">
        <div className="details container">
          <div className="left">
            <div className="main">
              <img src={fr13} alt="" />
            </div>
          </div>
          <div className="right">
            <span>Berries</span>
            <h1>Myrtle Berry</h1>
            <div className="price">₹ 200/kg</div>
            <form>
              <div>
                <select>
                  <option value="Select Quantity" selected="" disabled="">
                    Select Quantity
                  </option>
                  <option value={1}>250 gm</option>
                  <option value={2}>500 gm</option>
                  <option value={3}>1 kg</option>
                  <option value={4}>2 kg</option>
                </select>
                <span>
                  <i className="fas fa-chevron-down" />
                </span>
              </div>
            </form>
            <form className="form">
              <input type="text" placeholder={1} />
              <a href="cart.html" className="addCart">
                Add To Cart
              </a>
            </form>
            <h3>Product Detail</h3>
            <p>
              These are small but sweet in taste. Myrtle contains chemicals that
              might help fight against fungus and bacteria, and reduce swelling.
              People use myrtle for acne, canker sores, abnormally heavy
              bleeding during menstrual periods, persistent heartburn, warts,
              and many other conditions
            </p>
          </div>
        </div>
      </section>
      {/* Related Products */}
      <section className="section related-products">
        <div className="title mb-3 mt-5">
          <h3 className="d-flex justify-content-center fs-2 fw-bold">
            Related Products
          </h3>
          <span className="d-flex justify-content-center fs-4">
            Select from the premium product brands and save plenty money
          </span>
        </div>
        <div className="product-layout container">
          <div className="product">
            <div className="img-container">
              <img src={fr10} alt="" />
              <div className="addCart">
                <i className="fas fa-shopping-cart" />
              </div>
              <ul className="side-icons">
                <span>
                  <i className="far fa-heart" />
                </span>
                <span>
                  <i className="fas fa-sliders-h" />
                </span>
              </ul>
            </div>
            <div className="bottom">
              <Link to={"/Strawberry"} className="text-decoration-none">
                Strawberry
              </Link>
              <div className="price">
                <span>₹160/kg</span>
              </div>
            </div>
          </div>
          <div className="product">
            <div className="img-container">
              <img src={fr9} alt="" />
              <div className="addCart">
                <i className="fas fa-shopping-cart" />
              </div>
              <ul className="side-icons">
                <span>
                  <i className="far fa-heart" />
                </span>
                <span>
                  <i className="fas fa-sliders-h" />
                </span>
              </ul>
            </div>
            <div className="bottom">
              <Link to={"/Raspberry"} className="text-decoration-none">
                Red Raspberry
              </Link>
              <div className="price">
                <span>₹220/kg</span>
              </div>
            </div>
          </div>
          <div className="product">
            <div className="img-container">
              <img src={fr13} alt="" />
              <div className="addCart">
                <i className="fas fa-shopping-cart" />
              </div>
              <ul className="side-icons">
                <span>
                  <i className="far fa-heart" />
                </span>
                <span>
                  <i className="fas fa-sliders-h" />
                </span>
              </ul>
            </div>
            <div className="bottom">
              <Link to={"/Myrtleberry"} className="text-decoration-none">
                Myrtleberry
              </Link>
              <div className="price">
                <span>₹200/kg</span>
              </div>
            </div>
          </div>
          <div className="product">
            <div className="img-container">
              <img src={fr11} alt="" />
              <div className="addCart">
                <i className="fas fa-shopping-cart" />
              </div>
              <ul className="side-icons">
                <span>
                  <i className="far fa-heart" />
                </span>
                <span>
                  <i className="fas fa-sliders-h" />
                </span>
              </ul>
            </div>
            <div className="bottom">
              <Link to={"/Cranberry"} className="text-decoration-none">
                Cranberry
              </Link>
              <div className="price">
                <span>₹200/kg</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}
export default Myrtleberry;
