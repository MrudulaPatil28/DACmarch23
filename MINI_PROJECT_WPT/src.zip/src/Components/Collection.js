import Col from "react-bootstrap/Col";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import Image from "react-bootstrap/Image";
import Row from "react-bootstrap/Row";
import f1 from "./images/f1.jpg";
import f3 from "./images/f3.jpg";
import fr2 from "./images/fr2.jpg";
import fr3 from "./images/fr3.jpg";
import fr8 from "./images/fr8.jpg";
import v4 from "./images/v4.jpg";
import { Link } from "react-router-dom";
import "./Style.css";

function Collection() {
  return (
    <Container>
      <div className="title mb-3 mt-5">
        <h3 className="d-flex justify-content-center fs-2 fw-bold">
          Collections
        </h3>
        <span className="d-flex justify-content-center fs-4">
          Select from the premium product and save plenty money
        </span>
      </div>
      <Row className="justify-content-md-center">
        <Col xs={6} md={4} className="my-3">
          <div className="promotion-item">
            <Image src={f1} rounded />
            <div className="promotion-content text-light">
              <h3>Oranges</h3>
              <Button variant="primary">Shop Now</Button>
            </div>
          </div>
        </Col>
        <Col xs={6} md={4} className="my-3">
          <div className="promotion-item">
            <Image src={fr8} rounded />
            <div className="promotion-content text-light">
              <h3>BERRIES</h3>
              <Button variant="primary"><Link className="text-light text-decoration-none" to={"Berries"}>Shop Now</Link></Button>
            </div>
          </div>
        </Col>
        <Col xs={6} md={4} className="my-3">
          <div className="promotion-item">
            <Image src={f3} rounded />
            <div className="promotion-content text-light">
              <h3>MANGOS</h3>
              <Button variant="primary">Shop Now</Button>
            </div>
          </div>
        </Col>
        <Col xs={6} md={4} className="my-3">
          <div className="promotion-item">
            <Image src={v4} rounded />
            <div className="promotion-content text-light">
              <h3>GREEN VEGETABLES</h3>
              <Button variant="primary">Shop Now</Button>
            </div>
          </div>
        </Col>
        <Col xs={6} md={4} className="my-3">
          <div className="promotion-item">
            <Image src={fr3} rounded />
            <div className="promotion-content text-light">
              <h3>GRAPES</h3>
              <Button variant="primary">Shop Now</Button>
            </div>
          </div>
        </Col>
        <Col xs={6} md={4} className="my-3">
          <div className="promotion-item">
            <Image src={fr2} rounded />
            <div className="promotion-content text-light">
              <h3>APPLES</h3>
              <Button variant="primary">Shop Now</Button>
            </div>
          </div>
        </Col>
      </Row>
    </Container>
  );
}

export default Collection;
