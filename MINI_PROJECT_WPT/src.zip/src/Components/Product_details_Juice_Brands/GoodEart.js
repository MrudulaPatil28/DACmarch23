import Navbar from "./Nav";
import Footer from "./Footer";

function GoodEarth(){
return (
<>
<Navbar/>

  {/* PRODUCTS */}
  {/*Left category div*/}
  <section className="section products shadow-lg p-3 mb-5 bg-body-tertiary rounded">
    <div className="products-layout container">
      <div className="col-1-of-4">
        <div>
          <div className="block-title">
            <h3>Category</h3>
          </div>
          <ul className="block-content">
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span>All vegetbales</span>
                <small>(10)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span>Green leafy vegetables</span>
                <small>(7)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span> Root vegetabeles</span>
                <small>(3)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span> Sprouts</span>
                <small>(3)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span> Fruits</span>
                <small>(10)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span>Fruit Juices</span>
                <small>(15)</small>
              </label>
            </li>
          </ul>
        </div>
        <div>
          <div className="block-title">
            <h3>Organic Juice Brands</h3>
          </div>
          <ul className="block-content">
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span>Almaverde Bio</span>
                <small>(10)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span>Frootee </span>
                <small>(7)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span> Good Earth</span>
                <small>(3)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span>Green juice</span>
                <small>(3)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span>Juice Life</span>
                <small>(3)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span>Eden Organic</span>
                <small>(3)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span>Hippie Juice</span>
                <small>(3)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span>Juice</span>
                <small>(3)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span>Fruit Authority</span>
                <small>(3)</small>
              </label>
            </li>
            <li>
              <input type="checkbox" name="" id="" />
              <label htmlFor="">
                <span>Limon Freshness</span>
                <small>(3)</small>
              </label>
            </li>
          </ul>
        </div>
      </div>
      {/*sort category div top*/}
      <div className="col-3-of-4">
        <form action="">
          <div className="item">
            <label htmlFor="sort-by">Sort By</label>
            <select name="sort-by" id="sort-by">
              <option value="title" selected="selected">
                Min Price
              </option>
              <option value="number">Max Price</option>
              <option value="search_api_relevance">Relevance</option>
              <option value="created">Featured</option>
            </select>
          </div>
          <div className="item">
            <label htmlFor="order-by">Order</label>
            <select name="order-by" id="sort-by">
              <option value="ASC" selected="selected">
                ASC
              </option>
              <option value="DESC">DESC</option>
            </select>
          </div>
          <a href="">Apply</a>
        </form>
        {/*  All products   */}
        <div className="product-layout">
          {/*1*/}
          <div className="product">
            <div className="img-container ">
              <a href="/html_pages/Product_details_fruit_juices/cranberryJuice.html">
                <img src="/images/ju14.jpg" alt="" />
              </a>
              <div className="addCart">
                <i className="fas fa-shopping-cart" />
              </div>
              <ul className="side-icons">
                <span>
                  <i className="far fa-heart" />
                </span>
                <span>
                  <a href="/html_pages/Product_details_fruit_juices/cranberryJuice.html">
                    <i className="fas fa-sliders-h" />
                  </a>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="/html_pages/Product_details_fruit_juices/cranberryJuice.html">
                Cranberry Juice
              </a>
              <div className="price">
                <span>₹ 200 /1 lit</span>
              </div>
            </div>
          </div>
          {/*2*/}
          <div className="product">
            <div className="img-container">
              <a href="/html_pages/Product_details_fruit_juices/pomogranateJucie.html">
                <img src="/images/ju6.jpg" alt="" />
              </a>
              <div className="addCart">
                <i className="fas fa-shopping-cart" />
              </div>
              <ul className="side-icons">
                <span>
                  <i className="far fa-heart" />
                </span>
                <span>
                  <a href="/html_pages/Product_details_fruit_juices/pomogranateJucie.html">
                    <i className="fas fa-sliders-h" />
                  </a>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="/html_pages/Product_details_fruit_juices/dragonFruitJuice.html">
                Dragon Fruit Juice
              </a>
              <div className="price">
                <span>₹ 280 /1 lit</span>
              </div>
            </div>
          </div>
          {/*3*/}
          <div className="product">
            <div className="img-container">
              <a href="/html_pages/Product_details_fruit_juices/pomogranateJucie.html">
                <img src="/images/ju15.jpg" alt="" />
              </a>
              <div className="addCart">
                <i className="fas fa-shopping-cart" />
              </div>
              <ul className="side-icons">
                <span>
                  <i className="far fa-heart" />
                </span>
                <span>
                  <a href="/html_pages/Product_details_fruit_juices/pomogranateJucie.html">
                    <i className="fas fa-sliders-h" />
                  </a>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="/html_pages/Product_details_fruit_juices/pomogranateJucie.html">
                Pomegranate Juice
              </a>
              <div className="price">
                <span>₹ 280 /1 lit</span>
              </div>
            </div>
          </div>
          {/*4*/}
          <div className="product">
            <div className="img-container">
              <a href="/html_pages/Product_details_fruit_juices/strawberryJuice.html">
                <img src="/images/ju4.jpg" alt="" />
              </a>
              <div className="addCart">
                <i className="fas fa-shopping-cart" />
              </div>
              <ul className="side-icons">
                <span>
                  <i className="far fa-heart" />
                </span>
                <span>
                  <a href="/html_pages/Product_details_fruit_juices/strawberryJuice.html">
                    <i className="fas fa-sliders-h" />
                  </a>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="/html_pages/Product_details_fruit_juices/strawberryJuice.html">
                Strawberry Juice
              </a>
              <div className="price">
                <span>₹ 280 /1 lit</span>
              </div>
            </div>
          </div>
          {/*5*/}
          <div className="product">
            <div className="img-container">
              <a href="/html_pages/Product_details_fruit_juices/pineappleJuice.html">
                <img src="/images/ju5.jpg" alt="" />
              </a>
              <div className="addCart">
                <i className="fas fa-shopping-cart" />
              </div>
              <ul className="side-icons">
                <span>
                  <i className="far fa-heart" />
                </span>
                <span>
                  <a href="/html_pages/Product_details_fruit_juices/pineappleJuice.html">
                    <i className="fas fa-sliders-h" />
                  </a>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="/html_pages/Product_details_fruit_juices/pineappleJuice.html">
                Pineapple Juice
              </a>
              <div className="price">
                <span>₹ 260 /1 lit</span>
              </div>
            </div>
          </div>
          {/*6*/}
          <div className="product">
            <div className="img-container">
              <a href="/html_pages/Product_details_fruit_juices/watermellonJuice.html">
                <img src="/images/ju2.jpg" alt="" />
              </a>
              <div className="addCart">
                <i className="fas fa-shopping-cart" />
              </div>
              <ul className="side-icons">
                <span>
                  <i className="far fa-heart" />
                </span>
                <span>
                  <a href="/html_pages/Product_details_fruit_juices/watermellonJuice.html">
                    <i className="fas fa-sliders-h" />
                  </a>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="/html_pages/Product_details_fruit_juices/watermellonJuice.html">
                Watermellon Juice
              </a>
              <div className="price">
                <span>₹ 220 /1 lit </span>
              </div>
            </div>
          </div>
          {/*7*/}
          <div className="product">
            <div className="img-container">
              <a href="/html_pages/Product_details_fruit_juices/mangoJuice.html">
                <img src="/images/ju7.jpg" alt="" />
              </a>
              <div className="addCart">
                <i className="fas fa-shopping-cart" />
              </div>
              <ul className="side-icons">
                <span>
                  <i className="far fa-heart" />
                </span>
                <span>
                  <a href="/html_pages/Product_details_fruit_juices/mangoJuice.html">
                    <i className="fas fa-sliders-h" />
                  </a>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="/html_pages/Product_details_fruit_juices/mangoJuice.html">
                Mango Juice
              </a>
              <div className="price">
                <span>₹ 250 /1 lit </span>
              </div>
            </div>
          </div>
          {/*12*/}
          <div className="product">
            <div className="img-container">
              <a href="/html_pages/Product_details_fruit_juices/orangeJuice.html">
                <img src="/images/ju12.jpg" alt="" />
              </a>
              <div className="addCart">
                <i className="fas fa-shopping-cart" />
              </div>
              <ul className="side-icons">
                <span>
                  <i className="far fa-heart" />
                </span>
                <span>
                  <a href="/html_pages/Product_details_fruit_juices/orangeJuice.html">
                    <i className="fas fa-sliders-h" />
                  </a>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="/html_pages/Product_details_fruit_juices/orangeJuice.html">
                Orange Juice{" "}
              </a>
              <div className="price">
                <span>₹ 180 / 1 lit</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* PAGINATION */}
    <ul className="pagination">
      <span>1</span>
      <span>2</span>
      <span>3</span>
      <span>4</span>
      <span className="icon">››</span>
      <span className="last">Last »</span>
    </ul>
  </section>

  <Footer/>
</>

)
}
export default GoodEarth;