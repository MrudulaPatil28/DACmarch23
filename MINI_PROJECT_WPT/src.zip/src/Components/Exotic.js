import Col from "react-bootstrap/Col";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import f4 from "./images/f4.jpg";
import f5 from "./images/f5.jpg";
import f6 from "./images/f6.jpg";
import f7 from "./images/f7.jpg";
import f8 from "./images/f8.jpg";
import f9 from "./images/f9.jpg";
import f10 from "./images/f10.jpg";
import f11 from "./images/f11.jpg";
import "./Style.css";

function Exotic() {
  return (
    <Container>
      <div className="title mb-3 mt-5">
        <h3 className="d-flex justify-content-center fs-2 fw-bold">
          Exotic Fruits
        </h3>
        <span className="d-flex justify-content-center fs-4">
          Select from the premium product brands and save plenty money
        </span>
      </div>
      <Row className="justify-content-md-center">
        <Col xs={6} md={3} className="my-3">
          <div className="product">
            <div className="img-container">
              <img src={f8} alt="" />
              <div className="addCart">
                <i className="fas fa-shopping-cart"></i>
              </div>

              <ul className="side-icons">
                <span>
                  <i className="far fa-heart"></i>
                </span>
                <span>
                  <i className="fas fa-sliders-h"></i>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="" className="text-decoration-none">
                Raspberry
              </a>
              <div className="price">
                <span>₹ 220</span>
              </div>
            </div>
          </div>
        </Col>
        <Col xs={6} md={3} className="my-3">
          <div className="product">
            <div className="img-container">
              <img src={f9} alt="" />
              <div className="addCart">
                <i className="fas fa-shopping-cart"></i>
              </div>

              <ul className="side-icons">
                <span>
                  <i className="far fa-heart"></i>
                </span>
                <span>
                  <i className="fas fa-sliders-h"></i>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="" className="text-decoration-none">
                Papaya
              </a>
              <div className="price">
                <span>₹ 80</span>
              </div>
            </div>
          </div>
        </Col>
        <Col xs={6} md={3} className="my-3">
          <div className="product">
            <div className="img-container">
              <img src={f10} alt="" />
              <div className="addCart">
                <i className="fas fa-shopping-cart"></i>
              </div>

              <ul className="side-icons">
                <span>
                  <i className="far fa-heart"></i>
                </span>
                <span>
                  <i className="fas fa-sliders-h"></i>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="" className="text-decoration-none">
                Cherry
              </a>
              <div className="price">
                <span>₹ 120</span>
              </div>
            </div>
          </div>
        </Col>
        <Col xs={6} md={3} className="my-3">
          <div className="product">
            <div className="img-container">
              <img src={f11} alt="" />
              <div className="addCart">
                <i className="fas fa-shopping-cart"></i>
              </div>

              <ul className="side-icons">
                <span>
                  <i className="far fa-heart"></i>
                </span>
                <span>
                  <i className="fas fa-sliders-h"></i>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="" className="text-decoration-none">
                Kiwi
              </a>
              <div className="price">
                <span>₹ 180</span>
                <span className="cancel">₹ 200</span>
              </div>
            </div>
          </div>
        </Col>
        <Col xs={6} md={3} className="my-3">
          <div className="product">
            <div className="img-container">
              <img src={f4} alt="" />
              <div className="addCart">
                <i className="fas fa-shopping-cart"></i>
              </div>

              <ul className="side-icons">
                <span>
                  <i className="far fa-heart"></i>
                </span>
                <span>
                  <i className="fas fa-sliders-h"></i>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="" className="text-decoration-none">
                Blueberry
              </a>
              <div className="price">
                <span>₹ 150</span>
              </div>
            </div>
          </div>
        </Col>
        <Col xs={6} md={3} className="my-3">
          <div className="product">
            <div className="img-container">
              <img src={f5} alt="" />
              <div className="addCart">
                <i className="fas fa-shopping-cart"></i>
              </div>

              <ul className="side-icons">
                <span>
                  <i className="far fa-heart"></i>
                </span>
                <span>
                  <i className="fas fa-sliders-h"></i>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="" className="text-decoration-none">
                Dragon Fruit
              </a>
              <div className="price">
                <span>₹ 90</span>
              </div>
            </div>
          </div>
        </Col>
        <Col xs={6} md={3} className="my-3">
          <div className="product">
            <div className="img-container">
              <img src={f6} alt="" />
              <div className="addCart">
                <i className="fas fa-shopping-cart"></i>
              </div>

              <ul className="side-icons">
                <span>
                  <i className="far fa-heart"></i>
                </span>
                <span>
                  <i className="fas fa-sliders-h"></i>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="" className="text-decoration-none">
                Pomogranate
              </a>
              <div className="price">
                <span>₹ 80</span>
                <span className="cancel">₹ 130</span>
              </div>
            </div>
          </div>
        </Col>
        <Col xs={6} md={3} className="my-3">
          <div className="product">
            <div className="img-container">
              <img src={f7} alt="" />
              <div className="addCart">
                <i className="fas fa-shopping-cart"></i>
              </div>

              <ul className="side-icons">
                <span>
                  <i className="far fa-heart"></i>
                </span>
                <span>
                  <i className="fas fa-sliders-h"></i>
                </span>
              </ul>
            </div>
            <div className="bottom">
              <a href="" className="text-decoration-none">
                Strawberry
              </a>
              <div className="price">
                <span>₹ 150</span>
                <span className="cancel">₹ 180</span>
              </div>
            </div>
          </div>
        </Col>
      </Row>
    </Container>
  );
}

export default Exotic;
