import React from "react";
import "./Style.css";
import map from "./images/map.jpg";
import { Link } from "react-router-dom";
import AboutUs from "./AboutUs";

function Footer() {
  return (
    <>
      {/* Footer */}
      <footer id="footer" className="section footer">
        <div className="container">
          <div className="footer-container">
            <div className="footer-center">
              <h3>EXTRAS</h3>
              <span>
                <a href="/images/map.png">
                  <img
                    src={map}
                    alt=""
                    style={{ width: 275, height: 230, marginBottom: "-5px" }}
                  />
                </a>
              </span>
            </div>
            <div className="footer-center">
              <h3>INFORMATION</h3>
              <a>
                <Link to={"/about"}>About Us</Link>
              </a>
              <a href="#">Privacy Policy</a>
              <a href="#">Terms &amp; Conditions</a>
              <a>
                <Link to={"/contact"}>Contact Us</Link>
              </a>
              <a href="#">Site Map</a>
            </div>
            <div className="footer-center">
              <h3>MY ACCOUNT</h3>
              <a href="#">My Account</a>
              <a href="#">Order History</a>
              <a href="#">Wish List</a>
              <a href="#">Newsletter</a>
              <a href="#">Returns</a>
            </div>
            <div className="footer-center">
              <h3>CONTACT US</h3>
              <div>
                <span>
                  <i className="fas fa-map-marker-alt" />
                </span>
                28/2023, Shanti nagar, Andheri East, Mumbai
              </div>
              <div>
                <span>
                  <i className="far fa-envelope" />
                </span>
                FreshBasket@gmail.com
              </div>
              <div>
                <span>
                  <i className="fas fa-phone" />
                </span>
                +91-8484000011
              </div>
              <div className="payment-methods">
                <img src="/images/payment.png" alt="" />
              </div>
            </div>
          </div>
        </div>
      </footer>
      {/* End Footer */}
    </>
  );
}

export default Footer;
