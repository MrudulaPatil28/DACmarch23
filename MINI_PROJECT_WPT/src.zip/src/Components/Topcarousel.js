import Carousel from "react-bootstrap/Carousel";
import hero1 from "./images/hero1.jpeg";
import hero2 from "./images/hero2.jpeg";
import hero3 from "./images/hero3.jpg";

function Topcarousel() {
  return (
    <Carousel>
      <Carousel.Item interval={1000}>
        <img className="d-block w-100" src={hero1} alt="First slide" />
        <Carousel.Caption>
          <h2 className="text-success">
            Fresh vegetables <br />
            start from
            <span>₹60</span>
          </h2>
          <p className="text-success">
            Our vegetables & fruits are picked up fresh from the farm each day.
          </p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={1000}>
        <img className="d-block w-100" src={hero2} alt="Second slide" />
        <Carousel.Caption>
          <h2 className="text-success">
            On Your first Order
            <br />
            <span>30% off</span>
            on all vegetables & fruits
          </h2>
          <p className="text-success">Fresh handpicked products</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={1000}>
        <img className="d-block w-100" src={hero3} alt="Third slide" />
        <Carousel.Caption>
          <h2 className="text-success">
            On Your first Order
            <br />
            <span>20% off</span>
            on Juices
          </h2>
          <p className="text-success">Best chemical free fruit Juices</p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default Topcarousel;
