import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import about from "./images/AboutUs.jpg";
import mayur from "./images/mayur-pic.jpg";
import mrudula from "./images/mrudula-pic.jpg";
import sayli from "./images/sayali-pic.jpg";
import { Link } from "react-router-dom";

function AboutUs() {
  return (
    <>
      <Navbar />

      {/*about us*/}
      <section className="hero">
        <div className="container mt-3">
          <div className="hero-content">
            <h1>Welcome To Our Website</h1>
            <p className="fs-5">
              Fruit and vegetables should be an important part of your daily
              diet. They are naturally good and contain vitamins and minerals
              that can help to keep you healthy. They can also help protect
              against some diseases. Most Australians will benefit from eating
              more fruit and vegetables as part of a well-balanced, healthy diet
              and an active lifestyle. There are many varieties of fruit and
              vegetables available and many ways to prepare, cook and serve
              them.
            </p>
            <button className="btn btn-success">
              <Link to={"/"} className="text-light text-decoration-none">
                Learn More
              </Link>
            </button>
          </div>
          <div className="hero-image mt-3">
            <img src={about} />
          </div>
        </div>
      </section>
      <section>
        <div className="row d-flex justify-content-evenly ">
          <div className="col-md-3 col-sm-10 info mt-2 mb-2 p-3 ">
            <img src={mayur} alt="Mayur" className="border border-dark" />
            <div className="description">
              <p className="mt-2 fs-1">Mayur Bhole</p>
              <p className="fs-5">Web Designer</p>
              <p className="fs-5">bhole.mayur@outlook.com</p>
            </div>
          </div>
          <div className="col-md-3 col-sm-10 info mt-2 mb-2 p-3">
            <img src={mrudula} alt="Mayur" className="border border-dark" />
            <div className="description">
              <p className="mt-2 fs-1">Mrudula Patil</p>
              <p className="fs-5">Web Designer</p>
              <p className="fs-5">mrudulapatil28paris@gmail.com</p>
            </div>
          </div>
          <div className="col-md-3 col-sm-10 info mt-2 mb-2 p-3">
            <img src={sayli} alt="Sayali" className="border border-dark" />
            <div className="description">
              <p className="mt-2 fs-1">Sayali Chavan</p>
              <p className="fs-5">Web Designer</p>
              <p className="fs-5"> csayali587@gmail.com</p>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}
export default AboutUs;
