import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import Container from "react-bootstrap/Container";
import Col from "react-bootstrap/Col";
import Row from "react-bootstrap/Row";
import vgg1 from "./images/vgg1.jpg";
import vgg2 from "./images/vgg2.jpg";
import vgg3 from "./images/vgg3.jpg";
import vgg4 from "./images/vgg4.jpg";
import vgg5 from "./images/vgg5.jpg";
import vgg6 from "./images/vgg6.jpg";
import vgg7 from "./images/vgg7.jpg";
import vgg8 from "./images/vgg8.jpg";
import vgg10 from "./images/vgg10.jpg";
import vgg11 from "./images/vgg11.jpg";
import fr1 from "./images/fr1.jpg";
import fr3 from "./images/fr3.jpg";
import { Link } from "react-router-dom";

export default function AllProducts() {
  return (
    <>
      <Navbar />
      {/* PRODUCTS */}
      {/*Left category div*/}
      <section className="shadow-lg p-3 mb-5 bg-body-tertiary rounded">
        <Row className="justify-content-md-center">
          <Col xs={12} md={3}>
            <div className="col-1-of-4">
              <div>
                <div className="block-title">
                  <h3>Category</h3>
                </div>
                <ul className="block-content">
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span>All vegetbales</span>
                      <small>(10)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span>Green leafy vegetables</span>
                      <small>(7)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span> Root vegetabeles</span>
                      <small>(3)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span> Sprouts</span>
                      <small>(3)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span> Fruits</span>
                      <small>(10)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span>Fruit Juices</span>
                      <small>(15)</small>
                    </label>
                  </li>
                </ul>
              </div>
              <div>
                <div className="block-title">
                  <h3>Organic Juice Brands</h3>
                </div>
                <ul className="block-content">
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span>Almaverde Bio</span>
                      <small>(10)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span>Frootee </span>
                      <small>(7)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span> Good Earth</span>
                      <small>(3)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span>Green juice</span>
                      <small>(3)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span>Juice Life</span>
                      <small>(3)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span>Eden Organic</span>
                      <small>(3)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span>Hippie Juice</span>
                      <small>(3)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span>Juice</span>
                      <small>(3)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span>Fruit Authority</span>
                      <small>(3)</small>
                    </label>
                  </li>
                  <li>
                    <input type="checkbox" name="" id="" />
                    <label htmlFor="">
                      <span>Limon Freshness</span>
                      <small>(3)</small>
                    </label>
                  </li>
                </ul>
              </div>
            </div>
          </Col>

          <Col xs={12} md={9}>
            <div className="col-3-of-4">
              <form action="">
                <div className="item">
                  <label htmlFor="sort-by">Sort By</label>
                  <select name="sort-by" id="sort-by">
                    <option value="title" selected="selected">
                      Min Price
                    </option>
                    <option value="number">Max Price</option>
                    <option value="search_api_relevance">Relevance</option>
                    <option value="created">Featured</option>
                  </select>
                </div>
                <div className="item">
                  <label htmlFor="order-by">Order</label>
                  <select name="order-by" id="sort-by">
                    <option value="ASC" selected="selected">
                      ASC
                    </option>
                    <option value="DESC">DESC</option>
                  </select>
                </div>
                <a>Apply</a>
              </form>
            </div>
            <Container>
              <Row>
                {/*All products (some changes to add)*/}
                <Col xs={12} md={4}>
                  <div className="product">
                    <div className="img-container ">
                      <img src={vgg1} alt="" />
                      <div className="addCart">
                        <i className="fas fa-shopping-cart" />
                      </div>
                      <ul className="side-icons">
                        <span>
                          <i className="far fa-heart" />
                        </span>
                        <span>
                          <i className="fas fa-sliders-h" />
                        </span>
                      </ul>
                    </div>
                    <div className="bottom">
                      <Link to={""} className="text-decoration-none">
                        Cucumber
                      </Link>
                      <div className="price">
                        <span>₹ 70/kg</span>
                      </div>
                    </div>
                  </div>
                </Col>
                <Col xs={12} md={4}>
                  <div className="product">
                    <div className="img-container ">
                      <img src={vgg2} alt="" />
                      <div className="addCart">
                        <i className="fas fa-shopping-cart" />
                      </div>
                      <ul className="side-icons">
                        <span>
                          <i className="far fa-heart" />
                        </span>
                        <span>
                          <i className="fas fa-sliders-h" />
                        </span>
                      </ul>
                    </div>
                    <div className="bottom">
                      <Link to={""} className="text-decoration-none">
                        Garlic
                      </Link>
                      <div className="price">
                        <span>₹ 80/kg</span>
                      </div>
                    </div>
                  </div>
                </Col>
                <Col xs={12} md={4}>
                  <div className="product">
                    <div className="img-container ">
                      <img src={vgg3} alt="" />
                      <div className="addCart">
                        <i className="fas fa-shopping-cart" />
                      </div>
                      <ul className="side-icons">
                        <span>
                          <i className="far fa-heart" />
                        </span>
                        <span>
                          <i className="fas fa-sliders-h" />
                        </span>
                      </ul>
                    </div>
                    <div className="bottom">
                      <Link to={""} className="text-decoration-none">
                        Mix Bell pepers
                      </Link>
                      <div className="price">
                        <span>₹ 120/kg</span>
                      </div>
                    </div>
                  </div>
                </Col>
                <Col xs={12} md={4}>
                  <div className="product">
                    <div className="img-container ">
                      <img src={vgg4} alt="" />
                      <div className="addCart">
                        <i className="fas fa-shopping-cart" />
                      </div>
                      <ul className="side-icons">
                        <span>
                          <i className="far fa-heart" />
                        </span>
                        <span>
                          <i className="fas fa-sliders-h" />
                        </span>
                      </ul>
                    </div>
                    <div className="bottom">
                      <Link to={""} className="text-decoration-none">
                        Cauliflower
                      </Link>
                      <div className="price">
                        <span>₹ 80/kg</span>
                      </div>
                    </div>
                  </div>
                </Col>
                <Col xs={12} md={4}>
                  <div className="product">
                    <div className="img-container ">
                      <img src={vgg5} alt="" />
                      <div className="addCart">
                        <i className="fas fa-shopping-cart" />
                      </div>
                      <ul className="side-icons">
                        <span>
                          <i className="far fa-heart" />
                        </span>
                        <span>
                          <i className="fas fa-sliders-h" />
                        </span>
                      </ul>
                    </div>
                    <div className="bottom">
                      <Link to={""} className="text-decoration-none">
                        Zuccini
                      </Link>
                      <div className="price">
                        <span>₹ 80/kg</span>
                      </div>
                    </div>
                  </div>
                </Col>
                <Col xs={12} md={4}>
                  <div className="product">
                    <div className="img-container ">
                      <img src={vgg6} alt="" />
                      <div className="addCart">
                        <i className="fas fa-shopping-cart" />
                      </div>
                      <ul className="side-icons">
                        <span>
                          <i className="far fa-heart" />
                        </span>
                        <span>
                          <i className="fas fa-sliders-h" />
                        </span>
                      </ul>
                    </div>
                    <div className="bottom">
                      <Link to={""} className="text-decoration-none">
                        Palak
                      </Link>
                      <div className="price">
                        <span>₹ 60/kg</span>
                      </div>
                    </div>
                  </div>
                </Col>
                <Col xs={12} md={4}>
                  <div className="product">
                    <div className="img-container ">
                      <img src={vgg7} alt="" />
                      <div className="addCart">
                        <i className="fas fa-shopping-cart" />
                      </div>
                      <ul className="side-icons">
                        <span>
                          <i className="far fa-heart" />
                        </span>
                        <span>
                          <i className="fas fa-sliders-h" />
                        </span>
                      </ul>
                    </div>
                    <div className="bottom">
                      <Link to={""} className="text-decoration-none">
                        Red capsicum
                      </Link>
                      <div className="price">
                        <span>₹ 80/kg</span>
                      </div>
                    </div>
                  </div>
                </Col>
                <Col xs={12} md={4}>
                  <div className="product">
                    <div className="img-container ">
                      <img src={vgg8} alt="" />
                      <div className="addCart">
                        <i className="fas fa-shopping-cart" />
                      </div>
                      <ul className="side-icons">
                        <span>
                          <i className="far fa-heart" />
                        </span>
                        <span>
                          <i className="fas fa-sliders-h" />
                        </span>
                      </ul>
                    </div>
                    <div className="bottom">
                      <Link to={""} className="text-decoration-none">
                        Onions
                      </Link>
                      <div className="price">
                        <span>₹ 100/kg</span>
                      </div>
                    </div>
                  </div>
                </Col>
                <Col xs={12} md={4}>
                  <div className="product">
                    <div className="img-container ">
                      <img src={vgg11} alt="" />
                      <div className="addCart">
                        <i className="fas fa-shopping-cart" />
                      </div>
                      <ul className="side-icons">
                        <span>
                          <i className="far fa-heart" />
                        </span>
                        <span>
                          <i className="fas fa-sliders-h" />
                        </span>
                      </ul>
                    </div>
                    <div className="bottom">
                      <Link to={""} className="text-decoration-none">
                        Bok Choy
                      </Link>
                      <div className="price">
                        <span>₹ 80/kg</span>
                      </div>
                    </div>
                  </div>
                </Col>
                <Col xs={12} md={4}>
                  <div className="product">
                    <div className="img-container ">
                      <img src={fr1} alt="" />
                      <div className="addCart">
                        <i className="fas fa-shopping-cart" />
                      </div>
                      <ul className="side-icons">
                        <span>
                          <i className="far fa-heart" />
                        </span>
                        <span>
                          <i className="fas fa-sliders-h" />
                        </span>
                      </ul>
                    </div>
                    <div className="bottom">
                      <Link to={""} className="text-decoration-none">
                        Dragon Fruit
                      </Link>
                      <div className="price">
                        <span>₹ 120/kg</span>
                      </div>
                    </div>
                  </div>
                </Col>
                <Col xs={12} md={4}>
                  <div className="product">
                    <div className="img-container ">
                      <img src={fr3} alt="" />
                      <div className="addCart">
                        <i className="fas fa-shopping-cart" />
                      </div>
                      <ul className="side-icons">
                        <span>
                          <i className="far fa-heart" />
                        </span>
                        <span>
                          <i className="fas fa-sliders-h" />
                        </span>
                      </ul>
                    </div>
                    <div className="bottom">
                      <Link to={""} className="text-decoration-none">
                        Grapes
                      </Link>
                      <div className="price">
                        <span>₹ 120/kg</span>
                      </div>
                    </div>
                  </div>
                </Col>
                <Col xs={12} md={4}>
                  <div className="product">
                    <div className="img-container ">
                      <img src={vgg10} alt="" />
                      <div className="addCart">
                        <i className="fas fa-shopping-cart" />
                      </div>
                      <ul className="side-icons">
                        <span>
                          <i className="far fa-heart" />
                        </span>
                        <span>
                          <i className="fas fa-sliders-h" />
                        </span>
                      </ul>
                    </div>
                    <div className="bottom">
                      <Link to={""} className="text-decoration-none">
                        Kashmiri Chilli
                      </Link>
                      <div className="price">
                        <span>₹ 80/kg</span>
                      </div>
                    </div>
                  </div>
                </Col>
              </Row>
            </Container>
          </Col>
        </Row>

        {/* PAGINATION */}
        <ul className="pagination">
          <span>1</span>
          <span>2</span>
          <span>3</span>
          <span>4</span>
          <span className="icon">››</span>
          <span className="last">Last »</span>
        </ul>
      </section>
      <Footer />
    </>
  );
}
