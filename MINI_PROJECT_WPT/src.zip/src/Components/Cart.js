import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import vgg2 from "./images/vgg2.jpg";
import vgg3 from "./images/vgg3.jpg";
import vgg4 from "./images/vgg4.jpg";
import vgg6 from "./images/vgg6.jpg";
import vgg8 from "./images/vgg8.jpg";
import { Button } from "react-bootstrap";

const Cart = () => {
  return (
    <>
      <Navbar />
      {/* Cart Items */}
      <div className="d-flex justify-content-centre">
        <h1 className="mt-4 ms-5">Shopping Cart</h1>
      </div>
      <div className="container cart">
        <table>
          <tbody>
            <tr>
              <th>Product</th>
              <th>Quantity</th>
              <th>Subtotal</th>
            </tr>
            <tr>
              <td>
                <div className="cart-info">
                  <img src={vgg2} alt="" />
                  <div>
                    <p>Garlic</p>
                    <span>Price: ₹80</span>
                    <br />
                    <a href="#">remove</a>
                  </div>
                </div>
              </td>
              <td>
                <input type="number" defaultValue={1} min={1} />
              </td>
              <td>₹80.00</td>
            </tr>
            <tr>
              <td>
                <div className="cart-info">
                  <img src={vgg4} alt="" />
                  <div>
                    <p>Cauliflower</p>
                    <span>Price: ₹80</span>
                    <br />
                    <a href="#">remove</a>
                  </div>
                </div>
              </td>
              <td>
                <input type="number" defaultValue={1} min={1} />
              </td>
              <td>₹80.00</td>
            </tr>
            <tr>
              <td>
                <div className="cart-info">
                  <img src={vgg8} alt="" />
                  <div>
                    <p>Onions</p>
                    <span>Price: ₹100.00</span>
                    <br />
                    <a href="#">remove</a>
                  </div>
                </div>
              </td>
              <td>
                <input type="number" defaultValue={1} min={1} />
              </td>
              <td>₹100.00</td>
            </tr>
            <tr>
              <td>
                <div className="cart-info">
                  <img src={vgg6} alt="" />
                  <div>
                    <p>Spinach</p>
                    <span>Price: ₹60.00</span>
                    <br />
                    <a href="#">remove</a>
                  </div>
                </div>
              </td>
              <td>
                <input type="number" defaultValue={1} min={1} />
              </td>
              <td>₹60.00</td>
            </tr>
            <tr>
              <td>
                <div className="cart-info">
                  <img src={vgg3} alt="" />
                  <div>
                    <p>Orange</p>
                    <span>Price: ₹160.00</span>
                    <br />
                    <a href="#">remove</a>
                  </div>
                </div>
              </td>
              <td>
                <input type="number" defaultValue={1} min={1} />
              </td>
              <td>₹160.00</td>
            </tr>
          </tbody>
        </table>
        <div className="total-price">
          <table>
            <tbody>
              <tr>
                <td>Subtotal</td>
                <td>₹480</td>
              </tr>
              <tr>
                <td>Tax</td>
                <td>₹50</td>
              </tr>
              <tr>
                <td>Total</td>
                <td>₹530</td>
              </tr>
            </tbody>
          </table>
          <Button variant="outline-success">Proceed to Checkout</Button>{" "}
        </div>
      </div>

      <Footer />
    </>
  );
};

export default Cart;
