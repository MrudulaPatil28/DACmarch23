import React from "react";
import logo from "./images/logo.png";
import Badge from "react-bootstrap/Badge";
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <>
      <div>
        <nav className="navbar navbar-expand-lg bg-dark">
          <div className="container-fluid">
            <Link
              to={"/"}
              className="navbar-brand me-5 text-light fs-2 fw-bold"
            >
              <img src={logo} alt="logo" className="app-logo me-2" />
              Fresh Basket
            </Link>

            <button
              className="navbar-toggler text-light"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon text-light"></span>
            </button>
            <div
              className="collapse navbar-collapse"
              id="navbarSupportedContent"
            >
              <ul className="navbar-nav me-auto mb-2 mb-lg-0 ms-5">
                <li className="nav-item">
                  <Link to={"/"} className="nav-link active text-light">
                    Home
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to={"/AllProducts"} className="nav-link text-light">
                    Products
                  </Link>
                </li>
                <li className="nav-item dropdown">
                  <a
                    className="nav-link dropdown-toggle text-light"
                    href=""
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Shop
                  </a>
                  <ul className="dropdown-menu text-light bg-secondary">
                    <p className="p-2 fs-5">Shop By Category</p>
                    <li>
                      <a className="dropdown-item" href="">
                        All Vegetables
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item" href="">
                        Green Leafy Vegetables
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item" href="">
                        Root Vegetables
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item" href="">
                        Sprouts
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item" href="">
                        Fruits
                      </a>
                    </li>
                    <li>
                      <Link className="dropdown-item" to={"/juice1"}>
                        Fresh Juices
                      </Link>
                    </li>
                  </ul>
                </li>
                <li className="nav-item">
                  <Link to={"/login"} className="nav-link text-light">
                    Sign-In
                  </Link>
                </li>
                <li className="nav-item dropdown">
                  <a
                    className="nav-link dropdown-toggle text-light"
                    href=""
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Pages
                  </a>
                  <ul className="dropdown-menu bg-secondary">
                    <li>
                      <Link className="dropdown-item" to={"/about"}>
                        About Us
                      </Link>
                    </li>
                    <li>
                      <Link className="dropdown-item" to={"/contact"}>
                        Contact Us
                      </Link>
                    </li>
                  </ul>
                </li>
                {/* <li className="nav-item">
                  <a className="nav-link text-light" href="">
                    Wishlist
                    <Badge className="ms-1" bg="secondary">
                      0
                    </Badge>
                  </a>
                </li> */}
                <li className="nav-item">
                  <Link className="nav-link text-light" to={"/Cart"}>
                    Cart
                    <Badge className="ms-1" bg="secondary">
                      0
                    </Badge>
                  </Link>
                </li>
              </ul>
              <form className="d-flex" role="search">
                <input
                  className="form-control me-2"
                  type="search"
                  placeholder="Search"
                  aria-label="Search"
                />
                <button className="btn btn-outline-light" type="submit">
                  Search
                </button>
              </form>
            </div>
          </div>
        </nav>
      </div>
    </>
  );
}
