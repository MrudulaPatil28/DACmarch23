import "./Style.css";
import b1 from "./images/banner1.jpg";
import b2 from "./images/banner2.jpg";
import { Link } from "react-router-dom";

function FreshJuices() {
  return (
    <section className="section advert">
      <div className="title mb-3 mt-5">
        <h3 className="d-flex justify-content-center fs-2 fw-bold">
          Fresh Juices
        </h3>
        <span className="d-flex justify-content-center fs-4">
          Select from the premium product brands and save plenty money
        </span>
      </div>
      <section className="section advert mt-4">
        <div className="advert-layout container">
          <div className="item">
            <img src={b1} alt="" />
            <div className="content left">
              <span className="fs-4">Exclusive Sales</span>
              <h4>Organic Fruit Juices</h4>
              <Link to={"/Juice1"} className="fs-5 text-decoration-none">View Collection</Link>
            </div>
          </div>
          <div className="item">
            <img src={b2} alt="" />
            <div className="content right">
              <span className="fs-4">New Collection</span>
              <h4>Fresh Summer Drinks</h4>
              <Link to={"/Juice2"} className="fs-5 text-decoration-none">Shop Now</Link>
            </div>
          </div>
        </div>
      </section>
    </section>
  );
}

export default FreshJuices;
