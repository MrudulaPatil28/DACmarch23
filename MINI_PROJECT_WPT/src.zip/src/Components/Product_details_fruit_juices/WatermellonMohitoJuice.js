import Navbar from "./Nav";
import Footer from "./Footer";

function WatermellonMohitoJuice(){
return (
<>
<Navbar/>

  {/* Product Details */}
  <section className="section product-detail">
    <div className="details container">
      <div className="left">
        <div className="main">
          <img src="/images/ju2.jpg" alt="" />
        </div>
      </div>
      <div className="right">
        <span>Fruit Juice</span>
        <h1>Watermellon Mojito </h1>
        <div className="price">₹ 270 /1 lit</div>
        <form>
          <div>
            <select>
              <option value="Select Quantity" selected="" disabled="">
                Select Quantity
              </option>
              <option value={1}>250 gm</option>
              <option value={2}>500 gm</option>
              <option value={3}>1 kg</option>
              <option value={4}>2 kg</option>
            </select>
            <span>
              <i className="fas fa-chevron-down" />
            </span>
          </div>
        </form>
        <form className="form">
          <input type="text" placeholder={1} />
          <a href="cart.html" className="addCart">
            Add To Cart
          </a>
        </form>
        <h3>Product Detail</h3>
        <p>
          The Watermelon Mojito won't let you wait for the next summer to enjoy
          the freshness of watermelons. This rejuvenating mojito is prepared
          with fresh watermelon, mint and lime. This mojito contains the
          richness of micronutrients that comes with watermelons. This mojito is
          just what you need for those lazy days by the pool or in your backyard
          to refresh yourself with a sweet, juicy, summery flavour.
        </p>
      </div>
    </div>
  </section>
  {/* Related Products */}
  <section className="section related-products">
    <div className="title">
      <h2>Related Products</h2>
      <span>Select from the premium product brands and save plenty money</span>
    </div>
    <div className="product-layout container">
      {/*1*/}
      <div className="product">
        <div className="img-container">
          <a href="/html_pages/Product_details_fruit_juices/kiwiJuice.html">
            <img src="/images/ju8.jpg" alt="" />
          </a>
          <div className="addCart">
            <i className="fas fa-shopping-cart" />
          </div>
          <ul className="side-icons">
            <span>
              <i className="far fa-heart" />
            </span>
            <span>
              <a href="/html_pages/Product_details_fruit_juices/kiwiJuice.html">
                <i className="fas fa-sliders-h" />
              </a>
            </span>
          </ul>
        </div>
        <div className="bottom">
          <a href="/html_pages/Product_details_fruit_juices/kiwiJuice.html">
            Kiwi Juice
          </a>
          <div className="price">
            <span>₹ 220 /1 lit</span>
          </div>
        </div>
      </div>
      {/*2*/}
      <div className="product">
        <div className="img-container">
          <a href="/html_pages/Product_details_fruit_juices/mangoJuice.html">
            <img src="/images/ju7.jpg" alt="" />
          </a>
          <div className="addCart">
            <i className="fas fa-shopping-cart" />
          </div>
          <ul className="side-icons">
            <span>
              <i className="far fa-heart" />
            </span>
            <span>
              <a href="/html_pages/Product_details_fruit_juices/mangoJuice.html">
                <i className="fas fa-sliders-h" />
              </a>
            </span>
          </ul>
        </div>
        <div className="bottom">
          <a href="/html_pages/Product_details_fruit_juices/mangoJuice.html">
            Mango Jucie
          </a>
          <div className="price">
            <span>₹ 250 /1 lit</span>
          </div>
        </div>
      </div>
      {/*3*/}
      <div className="product">
        <div className="img-container">
          <a href="/html_pages/Product_details_fruit_juices/strawberryJuice.html">
            <img src="/images/ju4.jpg" alt="" />
          </a>
          <div className="addCart">
            <i className="fas fa-shopping-cart" />
          </div>
          <ul className="side-icons">
            <span>
              <i className="far fa-heart" />
            </span>
            <span>
              <a href="/html_pages/Product_details_fruit_juices/strawberryJuice.html">
                <i className="fas fa-sliders-h" />
              </a>
            </span>
          </ul>
        </div>
        <div className="bottom">
          <a href="/html_pages/Product_details_fruit_juices/strawberryJuice.html">
            strawberry Juice
          </a>
          <div className="price">
            <span>₹ 280 /1 lit</span>
          </div>
        </div>
      </div>
      {/*4*/}
      <div className="product">
        <div className="img-container">
          <a href="/html_pages/Product_details_fruit_juices/watermellonJuice.html">
            <img src="/images/ju3.jpg" alt="" />
          </a>
          <div className="addCart">
            <i className="fas fa-shopping-cart" />
          </div>
          <ul className="side-icons">
            <span>
              <i className="far fa-heart" />
            </span>
            <span>
              <a href="/html_pages/Product_details_fruit_juices/watermellonJuice.html">
                <i className="fas fa-sliders-h" />
              </a>
            </span>
          </ul>
        </div>
        <div className="bottom">
          <a href="/html_pages/Product_details_fruit_juices/watermellonJuice.html">
            watermellon Juice
          </a>
          <div className="price">
            <span>₹ 270 /1 lit</span>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <Footer/>
</>

)
}
export default WatermellonMohitoJuice;