import Navbar from "./Nav";
import Footer from "./Footer";

function StrawberryJuice(){
return (
<>
<Navbar/>

  {/* Product Details */}
  <section className="section product-detail">
    <div className="details container">
      <div className="left">
        <div className="main">
          <img src="/images/ju4.jpg" alt="" />
        </div>
      </div>
      <div className="right">
        <span>Fruit Juice</span>
        <h1>Strawberry Fruit Juice</h1>
        <div className="price">₹ 280 /1 lit</div>
        <form>
          <div>
            <select>
              <option value="Select Quantity" selected="" disabled="">
                Select Quantity
              </option>
              <option value={1}>250 gm</option>
              <option value={2}>500 gm</option>
              <option value={3}>1 kg</option>
              <option value={4}>2 kg</option>
            </select>
            <span>
              <i className="fas fa-chevron-down" />
            </span>
          </div>
        </form>
        <form className="form">
          <input type="text" placeholder={1} />
          <a href="cart.html" className="addCart">
            Add To Cart
          </a>
        </form>
        <h3>Product Detail</h3>
        <p>
          Organic strawberry juice can boost your metabolic activity, as
          strawberry juice is considered to contain high levels of vitamin B6,
          folate, riboflavin, niacin, and thiamine. These B-family vitamins play
          an essential part in metabolic activity, and can help boost energy and
          balance hormones
        </p>
      </div>
    </div>
  </section>
  {/* Related Products */}
  <section className="section related-products">
    <div className="title">
      <h2>Related Products</h2>
      <span>Select from the premium product brands and save plenty money</span>
    </div>
    <div className="product-layout container">
      {/*1*/}
      <div className="product">
        <div className="img-container">
          <a href="/html_pages/Product_details_fruit_juices/kiwiJuice.html">
            <img src="/images/ju8.jpg" alt="" />
          </a>
          <div className="addCart">
            <i className="fas fa-shopping-cart" />
          </div>
          <ul className="side-icons">
            <span>
              <i className="far fa-heart" />
            </span>
            <span>
              <a href="/html_pages/Product_details_fruit_juices/kiwiJuice.html">
                <i className="fas fa-sliders-h" />
              </a>
            </span>
          </ul>
        </div>
        <div className="bottom">
          <a href="/html_pages/Product_details_fruit_juices/kiwiJuice.html">
            Kiwi Juice
          </a>
          <div className="price">
            <span>₹ 220 /1 lit</span>
          </div>
        </div>
      </div>
      {/*2*/}
      <div className="product">
        <div className="img-container">
          <a href="/html_pages/Product_details_fruit_juices/mangoJuice.html">
            <img src="/images/ju7.jpg" alt="" />
          </a>
          <div className="addCart">
            <i className="fas fa-shopping-cart" />
          </div>
          <ul className="side-icons">
            <span>
              <i className="far fa-heart" />
            </span>
            <span>
              <a href="/html_pages/Product_details_fruit_juices/mangoJuice.html">
                <i className="fas fa-sliders-h" />
              </a>
            </span>
          </ul>
        </div>
        <div className="bottom">
          <a href="/html_pages/Product_details_fruit_juices/mangoJuice.html">
            Mango Jucie
          </a>
          <div className="price">
            <span>₹ 250 /1 lit</span>
          </div>
        </div>
      </div>
      {/*3*/}
      <div className="product">
        <div className="img-container">
          <a href="/html_pages/Product_details_fruit_juices/dragonFruitJuice.html">
            <img src="/images/ju9.jpg" alt="" />
          </a>
          <div className="addCart">
            <i className="fas fa-shopping-cart" />
          </div>
          <ul className="side-icons">
            <span>
              <i className="far fa-heart" />
            </span>
            <span>
              <a href="/html_pages/Product_details_fruit_juices/cranberryJuice.html">
                <i className="fas fa-sliders-h" />
              </a>
            </span>
          </ul>
        </div>
        <div className="bottom">
          <a href="/html_pages/Product_details_fruit_juices/cranberryJuice.html">
            Cranberry Juice
          </a>
          <div className="price">
            <span>₹ 200 /1 lit</span>
          </div>
        </div>
      </div>
      {/*4*/}
      <div className="product">
        <div className="img-container">
          <a href="/html_pages/Product_details_fruit_juices/cranberryJuice.html">
            <img src="/images/ju3.jpg" alt="" />
          </a>
          <div className="addCart">
            <i className="fas fa-shopping-cart" />
          </div>
          <ul className="side-icons">
            <span>
              <i className="far fa-heart" />
            </span>
            <span>
              <a href="/html_pages/Product_details_fruit_juices/watermellonJuice.html">
                <i className="fas fa-sliders-h" />
              </a>
            </span>
          </ul>
        </div>
        <div className="bottom">
          <a href="/html_pages/Product_details_fruit_juices/watermellonJuice.html">
            watermellon Juice
          </a>
          <div className="price">
            <span>₹ 270 /1 lit</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <Footer/>
</>

)
}
export default StrawberryJuice;