import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import React, { useEffect, useState } from "react";
import "./App.css";

import Login from "./Components/Login";
import SignUp from "./Components/SignUp";
import Home from "./Components/Home";
import Productall from "./Components/Productall";
import AboutUs from "./Components/AboutUs";
import ContactUs from "./Components/ContactUs";
import AllProducts from "./Components/AllProducts";
import Cart from "./Components/Cart";
import Tomato from "./Components/Product_details_featured/Tomato";
import BellPepper from "./Components/Product_details_featured/BellPepper";
import Mushroom from "./Components/Product_details_featured/Mushroom";
import BerriesCollection from "./Components/Product_details_berries/BerriesCollection";
import Blueberry from "./Components/Product_details_berries/Blueberry";
import Cherry from "./Components/Product_details_berries/Cherry";
import Cranberry from "./Components/Product_details_berries/Cranberry";
import Myrtleberry from "./Components/Product_details_berries/Myrtleberry";
import Raspberry from "./Components/Product_details_berries/Raspberry";
import Strawberry from "./Components/Product_details_berries/Strawberry";

import Juices1 from "./Components/Product_details_fruit_juices/FruitJuice1"
import Juices2 from "./Components/Product_details_fruit_juices/FruitJuice2"

//
function App() {
  //   const [Data, setData] = useState("");
  //   const getData = async () => {
  //     const response = await Axios.get("http://localhost:4005/getData");
  //     setData(response.data);
  //   };

  //   useEffect(() => {
  //     getData();
  //   }, []);
  // //
  return (
    <>
      <BrowserRouter>
        <Routes>
          {/** 1 Route means 1 Page */}
          {/* NAVBAR */}
          <Route path="/" element={<Home />} />
          <Route path="login" element={<Login />} />
          <Route path="login/signup" element={<SignUp />} />
          <Route path="about" element={<AboutUs />} />
          <Route path="contact" element={<ContactUs />} />
          <Route path="AllProducts" element={<AllProducts />} />
          <Route path="Cart" element={<Cart />} />

          {/* Featured */}
          <Route path="tomato" element={<Tomato />} />
          <Route path="bellpepper" element={<BellPepper />} />
          <Route path="mushroom" element={<Mushroom />} />
          {/* Collections */}
          <Route path="Berries" element={<BerriesCollection />} />
          <Route path="Blueberry" element={<Blueberry />} />
          <Route path="Cherry" element={<Cherry />} />
          <Route path="Raspberry" element={<Raspberry />} />
          <Route path="Strawberry" element={<Strawberry />} />
          <Route path="Cranberry" element={<Cranberry />} />
          <Route path="Myrtleberry" element={<Myrtleberry />} />

          <Route path="Juice1" element={<Juices1 />} />
          <Route path="Juice2" element={<Juices2 />} />

          <Route path="*" element={<h1>Page Not Found</h1>} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

// function ProtectedRoute({ children }) {
//   let loginStatus = localStorage.getItem("loginStatus");
//   if (!loginStatus) {
//     return <Navigate to={"login"} replace={true} />;
//   }
//   return children;
// }

export default App;
