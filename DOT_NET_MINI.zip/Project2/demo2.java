import java.util.Scanner;
public class demo2 {
String s= "abcd";

void  Reverse(){
   
}
  public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    
     
    

  }
}
