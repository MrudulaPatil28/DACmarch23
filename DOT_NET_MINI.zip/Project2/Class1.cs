﻿using MySql.Data.MySqlClient;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Project2
{
    class User
    {
        private static string connectionString = "SERVER=127.0.0.1:3306;DATABASE=bloodmanagement;UID=Madhu;PASSWORD=Patil;";

        //User Registration
        public void UserRegistration()
        {
            Console.Write("Enter your Emailid: ");
            string email = Validemail(Console.ReadLine());
            Console.Write("Enter your password: ");
            string password = Console.ReadLine();

            if (!checkUser(email, password))
            {
                Console.Write("\nEnter your First Name: ");
                string fname = Console.ReadLine();
                Console.Write("Enter your Last Name: ");
                string Lname = Console.ReadLine();
                Console.Write("Enter your Contact: ");
                string Phone = Validph(Console.ReadLine());
                if ((RegisterUser(email, password, fname, Lname, Phone)))
                    Console.WriteLine("Registration successful!");
                else { Console.WriteLine("Data not inserted"); }

            }
            else
            {
                Console.WriteLine("Username already exists. Please choose a different username.");
            }
            Program.User();
        }


        static bool checkUser(string email, string password)
        {
            using MySqlConnection connection = new MySqlConnection(connectionString);
            string query = "SELECT COUNT(*) FROM User WHERE Emailid = @email AND password = @password";

            connection.Open();
            using MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@password", password);
            int count = Convert.ToInt32(command.ExecuteScalar());
            return (count == 1);
        }

        static bool RegisterUser(string email, string password, string fname, string Lname, string Phone)
        {
            using MySqlConnection connection = new MySqlConnection(connectionString);
            string query = "INSERT INTO User (Fname,Lname,Phone,Emailid,Password) VALUES (@fname,@lname,@phone,@email,@password)";

            connection.Open();
            using MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@fname", fname);
            command.Parameters.AddWithValue("@lname", Lname);
            command.Parameters.AddWithValue("@Phone", Phone);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@password", password);

            try
            {
                command.ExecuteNonQuery();
                return true;
            }
            catch (MySqlException)
            {
                return false;
            }

        }





        //User Login
        public void UserLogin()
        {
            try
            {
                Console.Write("Enter your Email:");
                string email = Validemail(Console.ReadLine());
                Console.Write("Enter your password:");
                string password = Console.ReadLine();

                if (IsUserValid(email, password))
                {
                    Console.WriteLine("Login successful!");
                    using MySqlConnection connection = new MySqlConnection(connectionString);
                    string query = "SELECT FName,Lname FROM User WHERE Emailid = @email";

                    connection.Open();
                    using MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@email", email);

                    using MySqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        string FUser = reader.GetString("Fname");
                        string LUser = reader.GetString("Lname");
                        UserMenu(FUser, LUser);
                    }
                    if (!reader.HasRows)
                    {
                        Console.WriteLine("User not found.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid username or password.");
                }
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }


        }

        static bool IsUserValid(string email, string password)
        {
            using MySqlConnection connection = new MySqlConnection(connectionString);
            string query = "SELECT COUNT(*) FROM User WHERE Emailid = @email AND Password = @password";
            connection.Open();
            using MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@password", password);
            int count = Convert.ToInt32(command.ExecuteScalar());

            return count > 0;
        }

        static void UserMenu(string FUser, string LUser)
        {
            string choice;
            do
            {
                Console.WriteLine("---------------User----------------------");
                Console.WriteLine("1.View available BloodBags");
                Console.WriteLine("2.Book BloodBags");
                Console.WriteLine("3.View Bookings");
                Console.WriteLine("4.Logout");
                Console.Write("Enter your choice: ");
                choice = Console.ReadLine();


                switch (choice)
                {
                    case "1":
                        UserFunctionality.ViewBlood();
                        break;
                    case "2":
                        UserFunctionality.BookBloodByName(FUser, LUser);
                        break;
                    case "3":
                        UserFunctionality.UserBooking(FUser, LUser);
                        break;
                    case "4": 
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            } while (choice != "4");


        }


        //Validations
        private static string Validemail(string email)
        {
            Boolean check = Regex.IsMatch(email, @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$");
            if (!check)
            {
                Console.WriteLine("Invalid Emailid \nRe-enter Email:");
                string e = Validemail(Console.ReadLine());
            }
            return email;
        }

        /*  static string Validpswd(string pswd)
           {
               Boolean check = Regex.IsMatch(pswd, "^[A-Za-z][A-Za-z0-9_]{7,29}$");
               if (!check)
               {
                   Console.WriteLine("Invalid password\nReenter password:");
                   string e = Validpswd(Console.ReadLine());
               }

                   return pswd;
           }
         */
        static string Validph(string ph)
        {
            Boolean check = Regex.IsMatch(ph, "^\\d{10}$");
            if (!check)
            {
                Console.WriteLine("Invalid Contact\nReenter Contact:");
                string e = Validph(Console.ReadLine());
            }

            return ph;
        }

    }
}
