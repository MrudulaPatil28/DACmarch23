﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Project2
{
    class Donor
    {
        private static string connectionString = "SERVER=127.0.0.1:3306;DATABASE=bloodmanagement;UID=Madhu;PASSWORD=Patil;";

        //Donor Registration
        public void DonorRegistration()
        {
            Console.Write("Enter your Emailid: ");
            string email = Validemail(Console.ReadLine());
            Console.Write("Enter your password: ");
            string password = Console.ReadLine();

            if (!checkDonor(email, password))
            {
                Console.Write("\nEnter your First Name: ");
                string fname = Console.ReadLine();
                Console.Write("Enter your Last Name: ");
                string Lname = Console.ReadLine();
                Console.Write("Enter your Contact: ");
                string Phone = Validph(Console.ReadLine());
                if ((RegisterDonor(email, password, fname, Lname, Phone)))
                    Console.WriteLine("Registration successful!");
                else { Console.WriteLine("Data not inserted"); }

            }
            else
            {
                Console.WriteLine("Username already exists. Please choose a different username.");
            }
            Program.Donor();
        }


        static bool checkDonor(string email, string password)
        {
            using MySqlConnection connection = new MySqlConnection(connectionString);
            string query = "SELECT COUNT(*) FROM Donor WHERE Emailid = @email AND password = @password";

            connection.Open();
            using MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@password", password);
            int count = Convert.ToInt32(command.ExecuteScalar());
            return (count == 1);
        }

        static bool RegisterDonor(string email, string password, string fname, string Lname, string Phone)
        {
            using MySqlConnection connection = new MySqlConnection(connectionString);
            string query = "INSERT INTO Donor (Fname,Lname,Phone,Emailid,Password) VALUES (@fname,@lname,@phone,@email,@password)";

            connection.Open();
            using MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@fname", fname);
            command.Parameters.AddWithValue("@lname", Lname);
            command.Parameters.AddWithValue("@Phone", Phone);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@password", password);

            try
            {
                command.ExecuteNonQuery();
                return true;
            }
            catch (MySqlException)
            {
                return false;
            }

        }





        //Donor Login
        public void DonorLogin()
        {
            Console.Write("Enter your Email:");
            string email = Validemail(Console.ReadLine());
            Console.Write("Enter your password:");
            string password = Console.ReadLine();
            if (IsDonorValid(email, password))
            {
                Console.WriteLine("\nLogin successful!");
                using MySqlConnection connection = new MySqlConnection(connectionString);
                string query = "SELECT FName,Lname FROM Donor WHERE Emailid = @email";

                connection.Open();
                using MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@email", email);

                using MySqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string Fclient = reader.GetString("Fname");
                    string Lclient = reader.GetString("Lname");
                    DonorMenu(Fclient, Lclient);
                }
                if (!reader.HasRows)
                {
                    Console.WriteLine("Donor not found.");
                }
            }
            else
            {
                Console.WriteLine("Invalid username or password.");
            }

        }

        static bool IsDonorValid(string email, string password)
        {
            using MySqlConnection connection = new MySqlConnection(connectionString);
            string query = "SELECT COUNT(*) FROM Donor WHERE Emailid = @email AND Password = @password";
            connection.Open();
            using MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@password", password);
            int count = Convert.ToInt32(command.ExecuteScalar());

            return count > 0;
        }

        public void DonorMenu(string Fname, string Lname)
        {
            string choice;
            do
            {
                Console.WriteLine("----------------Admin---------------------");
                Console.WriteLine("1. Add Donor Details");
                Console.WriteLine("2. Delete Donor Details");
                Console.WriteLine("3. Update Donor Details");
                Console.WriteLine("4. View Donor Details");
                Console.WriteLine("5. Logout");
                Console.Write("Enter your choice: ");
                choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        DonorFunctionality.AddBlood(Fname, Lname);
                        break;
                    case "2":
                        DonorFunctionality.DeleteBlood();
                        break;
                    case "3":
                        DonorFunctionality.UpdateBlood();
                        break;
                    case "4":
                        DonorFunctionality.ViewBloodyOwner(Fname, Lname);
                        break;
                    case "5": break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }

            } while (choice != "5");
            //Program.Donor();
        }


        //Validations
        private static string Validemail(string email)
        {
            Boolean check = Regex.IsMatch(email, @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$");
            if (!check)
            {
                Console.WriteLine("Invalid Emailid ");
                Console.WriteLine("Reenter email: ");
                string e = Validemail(Console.ReadLine());
            }

            return email;
        }

        /*   static string Validpswd(string pswd)
           {
               Boolean check = Regex.IsMatch(pswd,"^[A-Za-z][A-Za-z0-9_]{7,29}$");
               if (!check)
               {
                   Console.WriteLine("\nInvalid password");
                  Console.WriteLine("Reenter password");
                  string e = Validpswd(ConsolePlus.ReadPassword());
               }

               return pswd;
           }*/

        static string Validph(string ph)
        {
            Boolean check = Regex.IsMatch(ph, "^\\d{10}$");
            if (!check)
            {
                Console.WriteLine("Invalid Contact\nReenter Contact: ");
                string e = Validph(Console.ReadLine());
            }

            return ph;
        }

    }
}
