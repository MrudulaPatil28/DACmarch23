﻿using ConsoleTables;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Project2
{
    internal class DonorFunctionality
    {
        private static string connectionString = "SERVER=127.0.0.1:3306;DATABASE=bloodmanagement;UID=Madhu;PASSWORD=Patil;";
        public static void AddBlood(string Fname, string Lname)
        {
            Console.Write("Enter Donor name: ");
            string Name = Console.ReadLine();
            Console.Write("Enter Blood Type [A+,B+,O+,A-,B-,O-,AB+,AB-]: ");
            string Type = Console.ReadLine();
            if (ValidateBloodType(Type))
            {
                Console.Write("Enter Blood Price: ");
                string Price = Console.ReadLine();
                Console.Write("Enter Blood location: ");
                string Location = Console.ReadLine();
                //Console.Write("Enter Blood details: ");
                //string Details = Console.ReadLine();
                //  Console.Write("Enter Blood BookingStatus: ");
                //  string BookingStatus = Console.ReadLine();

                string Donor = Fname + " " + Lname;

                using MySqlConnection connection = new MySqlConnection(connectionString);
                string query = "INSERT INTO Blood (Name,Type,Price,Location,BookingStatus,Donor,CustomerName) VALUES (@Name,@Type,@Price,@Location,'Not Booked',@Donor,'-')";

                connection.Open();
                using MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", Name);
                command.Parameters.AddWithValue("@Type", Type);
                command.Parameters.AddWithValue("@Price", Price);
                command.Parameters.AddWithValue("@Location", Location);
                //command.Parameters.AddWithValue("@Details", Details);
                // command.Parameters.AddWithValue("@BookingStatus",BookingStatus);
                command.Parameters.AddWithValue("@Donor", Donor);
                command.ExecuteNonQuery();

                Console.WriteLine("Donor details added successfully!");
            }
            else
            {
                Console.WriteLine("Invalid Blood Type");
            }
        }

        public static void UpdateBlood()
        {

            Console.Write("Enter the Donor name to update: ");
            string name = Console.ReadLine();
            if (checkName(name))
            {
                Console.Write("Enter Blood Type [A+,B+,O+,A-,B-,O-,AB+,AB-]: ");
                string Type = Console.ReadLine();
                if (ValidateBloodType(Type))
                { 
                    Console.Write("Enter Blood Price: ");
                    string Price = Console.ReadLine();
                    Console.Write("Enter Blood location: ");
                    string Location = Console.ReadLine();
                    //Console.Write("Enter Blood details: ");
                    //string Details = Console.ReadLine();
                    if ((Updateblood(name, Type, Price, Location)))
                        Console.WriteLine("Updation successful!");
                    else { 
                        Console.Error.WriteLine("Updation not successfull! "); 
                    }
                }else
                {
                    Console.WriteLine("Invalid Blood Type");
                }
            }
            else
            {
                Console.Error.WriteLine("Invalid Donor Name");
            }
        }
        public static bool ValidateBloodType(string bloodType)
        {
            // Define the regular expression pattern for valid blood types
            string pattern = @"^(A\+|B\+|O\+|A\-|B\-|O\-|AB\+|AB\-)$";

            // Use Regex.IsMatch to check if the input matches the pattern
            return Regex.IsMatch(bloodType, pattern);
        }

        static bool checkName(string name)
        {
            using MySqlConnection connection = new MySqlConnection(connectionString);
            string query = "SELECT COUNT(*) FROM Blood WHERE Name=@name";

            connection.Open();
            using MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@name", name);

            int count = Convert.ToInt32(command.ExecuteScalar());
            return (count == 1);
        }

        static bool Updateblood(string name, string Type, String Price, String Location)
        {
            using MySqlConnection connection = new MySqlConnection(connectionString);
            string query = "UPDATE Blood SET Type=@type,Price=@price,Location=@location WHERE Name=@name";

            connection.Open();
            using MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@type", Type);
            command.Parameters.AddWithValue("@price", Price);
            command.Parameters.AddWithValue("@location", Location);
            //command.Parameters.AddWithValue("@details", Details);
            command.Parameters.AddWithValue("@Name", name);

            try
            {
                command.ExecuteNonQuery();
                return true;
            }
            catch (MySqlException)
            {
                return false;
            }

        }

        public static void DeleteBlood()
        {
            try
            {
                Console.Write("Enter the Name of the Donor to delete: ");
                string name = Console.ReadLine();
                if (checkName(name))
                {
                    using MySqlConnection connection = new MySqlConnection(connectionString);
                    string query = "DELETE FROM Blood WHERE Name = @name";

                    connection.Open();
                    using MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@name", name);
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        Console.WriteLine("Donor deleted successfully!");
                    }
                    else
                    {
                        Console.WriteLine("Donor not found or unable to delete.");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Donor Name.");
                }
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("An error occurred while deleting the Donor: " + ex.Message);
            }
        }

        //view Blood by owner
        public static void ViewBloodyOwner(string Fname, string Lname)
        {
            try
            {
                string Donor = Fname + " " + Lname;
                using MySqlConnection connection = new MySqlConnection(connectionString);
                string query = "SELECT Name,Type,Price,Location,BookingStatus,CustomerName FROM Blood WHERE Donor=@Donor";

                connection.Open();
                using MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@Donor", Donor);

                using MySqlDataReader reader = command.ExecuteReader();
                var table = new ConsoleTable("NAME", "TYPE", "PRICE", "LOCATION", "BOOKING STATUS", "CUSTOMER NAME");
                while (reader.Read())
                {
                    string Bloodname = reader.GetString("Name");
                    string Bloodtype = reader.GetString("Type");
                    string Bloodprice = reader.GetString("Price");
                    string BloodLocation = reader.GetString("Location");
                    //string BloodDetail = reader.GetString("Details");
                    string Bookingstatus = reader.GetString("BookingStatus");
                    string customer = reader.GetString("CustomerName");

                    table.AddRow(Bloodname, Bloodtype, Bloodprice, BloodLocation, Bookingstatus, customer);
                }
                Console.WriteLine(table);
                if (!reader.HasRows)
                {
                    Console.WriteLine("Donor not found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while viewing the Donor: " + ex.Message);
            }
        }
    }
}
