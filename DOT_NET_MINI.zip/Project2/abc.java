class demo{


   demo(){
    System.out.println("hello world");
  }

  public static void main(String args[]){
     demo d= new demo();
   
  }
}