﻿namespace Project2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            

            while (true)
            {
                Console.WriteLine("-------------------------------------------------");
                Console.WriteLine("Welcome to Bloodbank Management System!");
                Console.WriteLine("1. Admin");
                Console.WriteLine("2. User");
                Console.WriteLine("3. Exit");
                Console.Write("Enter your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Donor();
                        break;
                    case "2":
                        User();
                        break;
                    case "3":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        public static void Donor()
        {
            string choice;
            do
            {
                Console.WriteLine("----------------Admin------------------");
                Console.WriteLine("1.Login");
                Console.WriteLine("2.Registration");
                Console.WriteLine("3. Exit");
                Console.Write("Enter your choice: ");
                choice = Console.ReadLine();
                Donor o = new Donor();
                switch (choice)
                {
                    case "1":
                        o.DonorLogin();
                        break;
                    case "2":
                        o.DonorRegistration();
                        break;
                    case "3": break;

                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }

            } while (choice != "3");

        }

        public static void User()
        {
            string choice;
            do
            {
                Console.WriteLine("----------------User------------------");
                Console.WriteLine("1.Login");
                Console.WriteLine("2.Registration");
                Console.WriteLine("3. Exit");
                Console.Write("Enter your choice: ");
                choice = Console.ReadLine();

                User c = new User();

                switch (choice)
                {
                    case "1":
                        c.UserLogin();
                        break;
                    case "2":
                        c.UserRegistration();
                        break;
                    case "3": break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
                //break;
            } while (choice != "3");

        }
    }
}