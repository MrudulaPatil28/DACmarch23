﻿using ConsoleTables;
using MySql.Data.MySqlClient;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Project2
{
    internal class UserFunctionality
    {
        private static string connectionString = "SERVER=127.0.0.1:3306;DATABASE=bloodmanagement;UID=Madhu;PASSWORD=Patil;";

        public static void ViewBlood()
        {
            try
            {
                Console.Write("Enter Blood Type [A+,B+,O+,A-,B-,O-,AB+,AB-]: ");
                string BloodType = Console.ReadLine();
                if(ValidateBloodType(BloodType)) { 
                using MySqlConnection connection = new MySqlConnection(connectionString);
                string query = "SELECT Name,Type,Price,Location,BookingStatus,Donor FROM Blood WHERE Type = @type AND BookingStatus='Not Booked'";

                connection.Open();
                using MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@type", BloodType);

                using MySqlDataReader reader = command.ExecuteReader();
                var table = new ConsoleTable("NAME", "TYPE", "PRICE", "LOCATION", "BOOKING STATUS", "Donor");
                while (reader.Read())
                {
                    string Bloodname = reader.GetString("Name");
                    string Bloodtype = reader.GetString("Type");
                    string Bloodprice = reader.GetString("Price");
                    string BloodLocation = reader.GetString("Location");
                    //string BloodDetail = reader.GetString("Details");
                    string Bookingstatus = reader.GetString("BookingStatus");
                    string Donor = reader.GetString("Donor");


                    table.AddRow(Bloodname, Bloodtype, Bloodprice, BloodLocation, Bookingstatus, Donor);
                    
                }
                Console.WriteLine(table);
                if (!reader.HasRows)
                {
                    Console.WriteLine("Bloodbag not found.");
                }
                }
                else
                {
                    Console.WriteLine("Invalid Blood Type");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while viewing the Blood Bag: " + ex.Message);
            }
        }

        public static bool ValidateBloodType(string bloodType)
        {
            // Define the regular expression pattern for valid blood types
            string pattern = @"^(A\+|B\+|O\+|A\-|B\-|O\-|AB\+|AB\-)$";

            // Use Regex.IsMatch to check if the input matches the pattern
            return Regex.IsMatch(bloodType, pattern);
        }
        //Blood booking
        public static void BookBloodByName(string Fname, string Lname)
        {
            try
            {
                Console.Write("Enter Donor name: ");
                string DonorName = Console.ReadLine();
                if (checkBooking(DonorName))
                {
                    string User = Fname + " " + Lname;
                    using MySqlConnection connection = new MySqlConnection(connectionString);
                    string query = "UPDATE Blood SET BookingStatus ='Booked',CustomerName=@name WHERE Name = @DonorName";

                    connection.Open();
                    using MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@name", User);
                    command.Parameters.AddWithValue("@DonorName", DonorName);
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        Console.WriteLine($"Donor '{DonorName}' booked successfully!");
                    }
                }
                else
                {
                    Console.WriteLine("Bloodbag by "+ DonorName + " is already booked!!.Go for another Donor.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while booking the Donor: " + ex.Message);
            }
        }
        //booking status checking
        public static bool checkBooking(string DonorName)
        {
            try
            {
                using MySqlConnection connection = new MySqlConnection(connectionString);
                string query = "SELECT BookingStatus FROM Blood WHERE Name=@name";

                connection.Open();
                using MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@name", DonorName);

                using MySqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string status = reader.GetString("BookingStatus");
                    if (status.Equals("Not Booked"))
                    {
                        return true;
                    }
                }


            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
            return false;
        }




        //view User bookings
        public static void UserBooking(string Fname, string Lname)
        {
            try
            {
                string User = Fname + " " + Lname;
                using MySqlConnection connection = new MySqlConnection(connectionString);
                string query = "SELECT Name,Type,Price,Location,Donor FROM Blood WHERE CustomerName = @cn";

                connection.Open();
                using MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@cn", User);

                using MySqlDataReader reader = command.ExecuteReader();
                var table = new ConsoleTable("NAME", "TYPE", "PRICE", "LOCATION", "Donor");


                while (reader.Read())
                {
                    string Bloodname = reader.GetString("Name");
                    string Bloodtype = reader.GetString("Type");
                    string Bloodprice = reader.GetString("Price");
                    string BloodLocation = reader.GetString("Location");
                    //string BloodDetail = reader.GetString("Details");
                    string Donor = reader.GetString("Donor");


                    table.AddRow(Bloodname, Bloodtype, Bloodprice, BloodLocation, Donor);
                }
                Console.WriteLine(table);
                if (!reader.HasRows)
                {
                    Console.WriteLine("Donor not found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while viewing the Donor: " + ex.Message);
            }
        }
    }
}
